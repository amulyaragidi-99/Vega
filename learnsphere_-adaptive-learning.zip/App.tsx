
import React, { useEffect, useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Landing } from './pages/Landing';
import { Dashboard } from './pages/Dashboard';
import { LearningPath } from './pages/LearningPath';
import { Lesson } from './pages/Lesson';
import { Quiz } from './pages/Quiz';
import { Auth } from './pages/Auth';
import { Certificate } from './pages/Certificate';
import { Settings } from './pages/Settings';
import { Progress } from './pages/Progress';
import { Layout } from './components/Layout';
import { AIAssistant } from './components/AIAssistant';
import { storageService } from './services/storage';
import { SplashScreen } from './components/SplashScreen';

const App: React.FC = () => {
  const [isAppReady, setIsAppReady] = useState(false);

  useEffect(() => {
    const stats = storageService.getUserStats();
    if (stats.settings) {
      storageService.applyTheme(stats.settings);
    }
  }, []);

  if (!isAppReady) {
    return <SplashScreen onComplete={() => setIsAppReady(true)} />;
  }

  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Auth type="login" />} />
        <Route path="/signup" element={<Auth type="signup" />} />
        
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/path" element={<Layout><LearningPath /></Layout>} />
        <Route path="/lesson/:id" element={<Layout><Lesson /></Layout>} />
        <Route path="/quiz" element={<Layout><Quiz /></Layout>} />
        <Route path="/certificate" element={<Layout><Certificate /></Layout>} />
        <Route path="/settings" element={<Layout><Settings /></Layout>} />
        <Route path="/progress" element={<Layout><Progress /></Layout>} />
        
        <Route path="/profile" element={<Layout><div className="text-center py-20 font-bold opacity-50 uppercase tracking-widest">Profile: Super User v1.0</div></Layout>} />
        
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
      <AIAssistant />
    </HashRouter>
  );
};

export default App;
