
export enum LessonStatus {
  LOCKED = 'LOCKED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED'
}

export type StudyMode = 'text' | 'audio' | 'visual';

export interface Flashcard {
  front: string;
  back: string;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  content: string;
  initialCode: string;
  solution: string;
  duration: string;
  xpReward: number;
  status: LessonStatus;
}

export interface Level {
  id: number;
  title: string;
  lessons: Lesson[];
  quizPassed?: boolean;
}

export interface ThemeSettings {
  primaryColor: string;
  fontSize: 'small' | 'medium' | 'large';
  highContrast: boolean;
  darkMode: boolean;
  learningPreference: StudyMode;
}

export interface UserStats {
  name: string;
  email: string;
  xp: number;
  streak: number;
  badges: string[];
  completedLessonIds: string[];
  passedQuizIds: string[];
  xpHistory: { date: string; amount: number }[];
  lastDailyChallengeDate: string | null;
  settings?: ThemeSettings;
}

export interface QuizQuestion {
  id: string;
  levelId?: number;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export interface Feedback {
  id: string;
  rating: number;
  comment: string;
  timestamp: number;
}

export interface Notification {
  id: string;
  message: string;
  type: 'info' | 'success' | 'warning';
}
