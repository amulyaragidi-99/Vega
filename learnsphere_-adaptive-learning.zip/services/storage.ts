
import { UserStats, Level, LessonStatus, Feedback, ThemeSettings } from '../types';
import { INITIAL_LEVELS } from '../constants';

const STATS_KEY = 'learnsphere_user_stats_ml_v3';
const LEVELS_KEY = 'learnsphere_levels_ml_v3';
const FEEDBACK_KEY = 'learnsphere_feedback_ml_v3';

const DEFAULT_SETTINGS: ThemeSettings = {
  primaryColor: '139, 92, 246', // Modern Violet
  fontSize: 'medium',
  highContrast: false,
  darkMode: false,
  learningPreference: 'text'
};

export const storageService = {
  getUserStats: (): UserStats => {
    const data = localStorage.getItem(STATS_KEY);
    const today = new Date().toISOString().split('T')[0];
    
    if (!data) {
      return {
        name: 'Guest Explorer',
        email: '',
        xp: 0,
        streak: 1,
        badges: [],
        completedLessonIds: [],
        passedQuizIds: [],
        xpHistory: [{ date: today, amount: 0 }],
        lastDailyChallengeDate: null,
        settings: DEFAULT_SETTINGS
      };
    }
    
    const stats = JSON.parse(data);
    
    // Streak logic update on retrieval
    const lastActivity = stats.xpHistory && stats.xpHistory.length > 0 
      ? stats.xpHistory[stats.xpHistory.length - 1].date 
      : null;
      
    if (lastActivity && lastActivity !== today) {
      const lastDate = new Date(lastActivity);
      const todayDate = new Date(today);
      const diffTime = Math.abs(todayDate.getTime() - lastDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (diffDays > 1) {
        stats.streak = 1; // Reset streak if missed more than a day
      }
    }

    if (!stats.settings) stats.settings = DEFAULT_SETTINGS;
    if (!stats.xpHistory) stats.xpHistory = [{ date: today, amount: 0 }];
    return stats;
  },

  saveUserStats: (stats: UserStats) => {
    localStorage.setItem(STATS_KEY, JSON.stringify(stats));
    storageService.applyTheme(stats.settings || DEFAULT_SETTINGS);
  },

  applyTheme: (settings: ThemeSettings) => {
    const root = document.documentElement;
    root.style.setProperty('--primary-rgb', settings.primaryColor);
    const fontSizes = { small: '14px', medium: '16px', large: '20px' };
    root.style.setProperty('--font-size-base', fontSizes[settings.fontSize]);
    settings.darkMode ? root.classList.add('dark') : root.classList.remove('dark');
    settings.highContrast ? root.classList.add('high-contrast') : root.classList.remove('high-contrast');
  },

  getLevels: (): Level[] => {
    const data = localStorage.getItem(LEVELS_KEY);
    if (!data) return INITIAL_LEVELS;
    return JSON.parse(data);
  },

  saveLevels: (levels: Level[]) => {
    localStorage.setItem(LEVELS_KEY, JSON.stringify(levels));
  },

  completeLesson: (lessonId: string, xpReward: number) => {
    const stats = storageService.getUserStats();
    const levels = storageService.getLevels();
    const today = new Date().toISOString().split('T')[0];

    if (!stats.completedLessonIds.includes(lessonId)) {
      stats.completedLessonIds.push(lessonId);
      stats.xp += xpReward;
      
      // Update History and Streak
      const lastHist = stats.xpHistory[stats.xpHistory.length - 1];
      if (lastHist && lastHist.date === today) {
        lastHist.amount += xpReward;
      } else {
        // Increment streak if yesterday was the last activity
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayStr = yesterday.toISOString().split('T')[0];
        if (lastHist && lastHist.date === yesterdayStr) {
          stats.streak += 1;
        } else if (!lastHist) {
          stats.streak = 1;
        }
        stats.xpHistory.push({ date: today, amount: xpReward });
      }

      if (stats.completedLessonIds.length === 1 && !stats.badges.includes('newbie')) {
        stats.badges.push('newbie');
      }

      // Progression Logic
      const allLessons = levels.flatMap(l => l.lessons);
      const currentIdx = allLessons.findIndex(l => l.id === lessonId);
      
      // Mark current as completed in level data
      levels.forEach(lvl => {
        lvl.lessons.forEach(l => {
          if (l.id === lessonId) l.status = LessonStatus.COMPLETED;
        });
      });

      // Unlock next node
      if (allLessons[currentIdx + 1]) {
        const nextId = allLessons[currentIdx + 1].id;
        levels.forEach(lvl => {
          lvl.lessons.forEach(l => {
            if (l.id === nextId && l.status === LessonStatus.LOCKED) {
              l.status = LessonStatus.IN_PROGRESS;
            }
          });
        });
      }

      storageService.saveUserStats(stats);
      storageService.saveLevels(levels);
    }
  },

  completeDailyChallenge: (xpReward: number) => {
    const stats = storageService.getUserStats();
    const today = new Date().toISOString().split('T')[0];

    if (stats.lastDailyChallengeDate !== today) {
      stats.lastDailyChallengeDate = today;
      stats.xp += xpReward;

      const lastHist = stats.xpHistory[stats.xpHistory.length - 1];
      if (lastHist && lastHist.date === today) {
        lastHist.amount += xpReward;
      } else {
        stats.xpHistory.push({ date: today, amount: xpReward });
      }

      if (!stats.badges.includes('daily-hero')) {
        stats.badges.push('daily-hero');
      }

      storageService.saveUserStats(stats);
      return true;
    }
    return false;
  },

  passLevelQuiz: (levelId: number) => {
    const stats = storageService.getUserStats();
    const levels = storageService.getLevels();
    const levelIndex = levelId - 1;

    if (levels[levelIndex]) {
      levels[levelIndex].quizPassed = true;
      if (levels[levelIndex + 1]) {
        levels[levelIndex + 1].lessons[0].status = LessonStatus.IN_PROGRESS;
      }
      
      if (levelId === 3 && !stats.badges.includes('math-wizard')) stats.badges.push('math-wizard');
      if (levelId === 5 && !stats.badges.includes('data-scientist')) stats.badges.push('data-scientist');
      
      storageService.saveLevels(levels);
      storageService.saveUserStats(stats);
    }
  },

  isPathCompleted: (): boolean => {
    const levels = storageService.getLevels();
    return levels.every(l => l.lessons.every(less => less.status === LessonStatus.COMPLETED));
  },

  saveFeedback: (feedback: Omit<Feedback, 'id' | 'timestamp'>) => {
    const existing = JSON.parse(localStorage.getItem(FEEDBACK_KEY) || '[]');
    existing.push({ ...feedback, id: Math.random().toString(36).substr(2, 9), timestamp: Date.now() });
    localStorage.setItem(FEEDBACK_KEY, JSON.stringify(existing));
  },

  resetProgress: () => {
    localStorage.removeItem(STATS_KEY);
    localStorage.removeItem(LEVELS_KEY);
    localStorage.removeItem(FEEDBACK_KEY);
    window.location.reload();
  }
};
