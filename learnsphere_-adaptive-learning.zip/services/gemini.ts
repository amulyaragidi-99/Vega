
import { GoogleGenAI, Modality, Type } from "@google/genai";
import { ChatMessage } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const askMentor = async (history: ChatMessage[], currentQuestion: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: [
        ...history.map(h => ({ role: h.role, parts: [{ text: h.text }] })),
        { role: 'user', parts: [{ text: currentQuestion }] }
    ],
    config: {
      systemInstruction: `You are "Sphere", an expert and encouraging AI Machine Learning Mentor for the LearnSphere Academy. 
      Your goal is to help beginners and intermediate learners master ML, Deep Learning, and AI ethics. 
      Keep your answers short, focused on mathematics and logic behind algorithms, and use emojis. 
      If the user asks for code solutions, emphasize libraries like Scikit-learn, TensorFlow, or PyTorch.
      Focus on Machine Learning topics only.`,
      temperature: 0.7,
      topP: 0.9,
    },
  });

  // Accessing text property directly
  return response.text || "I'm sorry, my neural pathways are a bit tangled. Try rephrasing!";
};

export const generateLessonAudio = async (text: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash-preview-tts",
    contents: [{ parts: [{ text: `Narrate a conversational, slightly paraphrased version of the following Machine Learning educational content. Do not read it word-for-word; instead, explain it like a helpful mentor would during a live lecture. Keep the tone engaging and professional. Text to narrate: ${text}` }] }],
    config: {
      // Modality.AUDIO is required for text-to-speech
      responseModalities: [Modality.AUDIO],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: { voiceName: 'Kore' },
        },
      },
    },
  });

  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  return base64Audio;
};

export const generateVisualSummary = async (lessonTitle: string, content: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Transform this Machine Learning lesson into a high-level visual roadmap. 
    Use mermaid-style logic (represented by indented lists or boxes), flowcharts (Step A -> Step B), and summary diagrams.
    Make it highly structured and logical for a visual learner.
    Lesson: ${lessonTitle}
    Content: ${content}`,
    config: {
      systemInstruction: "You are an ML curriculum designer specializing in infographics and flowcharts. Your output should be logically hierarchical and emphasize steps and relationships over long text blocks.",
    }
  });
  // Accessing text property directly
  return response.text;
};

export const generateLessonMCQs = async (lessonTitle: string, content: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Generate exactly 5 high-quality Multiple Choice Questions (MCQs) for the lesson "${lessonTitle}" based on this content: "${content}". 
    Each question should have 4 options and 1 correct answer.
    Return the response in a structured JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            // Adding id property to satisfy the QuizQuestion interface
            id: { type: Type.STRING },
            question: { type: Type.STRING },
            options: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING },
              minItems: 4,
              maxItems: 4
            },
            correctAnswer: { type: Type.INTEGER, description: "Index of the correct option (0-3)" },
            explanation: { type: Type.STRING }
          },
          required: ["id", "question", "options", "correctAnswer", "explanation"]
        }
      }
    }
  });
  // Accessing text property directly
  return JSON.parse(response.text);
};

export const generateFlashcards = async (lessonTitle: string, content: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Generate exactly 5 flashcards for the lesson "${lessonTitle}" based on this content: "${content}". 
    Each card has a 'front' (concept/question) and 'back' (definition/answer).
    Return the response in a structured JSON format.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            front: { type: Type.STRING },
            back: { type: Type.STRING }
          },
          required: ["front", "back"]
        }
      }
    }
  });
  // Accessing text property directly
  return JSON.parse(response.text);
};
