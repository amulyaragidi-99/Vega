
import { LessonStatus, Level, QuizQuestion } from './types';

export const INITIAL_LEVELS: Level[] = [
  {
    id: 1,
    title: "Level 1: ML Foundations",
    lessons: [
      { id: "1-1", title: "What is Machine Learning?", description: "Learn the core concepts of AI and ML.", content: "Machine Learning is a subset of AI that focuses on building systems that learn from data. Instead of explicit programming, we use algorithms to find patterns.", initialCode: "# Define a basic variable\nlearning_mode = True\nprint('ML is fun')", solution: "print", duration: "5 min", xpReward: 50, status: LessonStatus.IN_PROGRESS },
      { id: "1-2", title: "Types of Learning", description: "Supervised vs Unsupervised learning.", content: "Supervised learning uses labeled data. Unsupervised learning finds hidden structures in unlabeled data.", initialCode: "# Which one uses labels?\nanswer = ''", solution: "supervised", duration: "8 min", xpReward: 100, status: LessonStatus.LOCKED },
      { id: "1-3", title: "Data is Fuel", description: "The importance of data quality.", content: "Garbage In, Garbage Out. ML models are only as good as the data they consume.", initialCode: "data_quality = 'High'\nif data_quality == 'High':\n  print('Proceed')", solution: "if", duration: "5 min", xpReward: 100, status: LessonStatus.LOCKED }
    ]
  },
  {
    id: 2,
    title: "Level 2: Data Preprocessing",
    lessons: [
      { id: "2-1", title: "Cleaning Data", description: "Handling missing values and outliers.", content: "Real-world data is messy. We need to handle null values before training.", initialCode: "import pandas as pd\ndf.dropna()", solution: "dropna", duration: "10 min", xpReward: 150, status: LessonStatus.LOCKED },
      { id: "2-2", title: "Feature Scaling", description: "Normalization and Standardization.", content: "Features with different scales can confuse models. Scaling brings them to a similar range.", initialCode: "scaled_x = (x - min) / (max - min)", solution: "min", duration: "12 min", xpReward: 150, status: LessonStatus.LOCKED }
    ]
  },
  { id: 3, title: "Level 3: Regression", lessons: [{ id: "3-1", title: "Linear Regression", description: "Predicting continuous values.", content: "Find the line of best fit (y = mx + b).", initialCode: "y = m*x + b", solution: "m*x", duration: "15 min", xpReward: 200, status: LessonStatus.LOCKED }] },
  { id: 4, title: "Level 4: Classification", lessons: [{ id: "4-1", title: "Logistic Regression", description: "Binary classification tasks.", content: "Predicting yes or no (0 or 1).", initialCode: "probability = sigmoid(z)", solution: "sigmoid", duration: "15 min", xpReward: 200, status: LessonStatus.LOCKED }] },
  { id: 5, title: "Level 5: Decision Trees", lessons: [{ id: "5-1", title: "Tree Models", description: "Learning how trees split data.", content: "Nodes, leaves, and entropy.", initialCode: "tree.fit(X, y)", solution: "fit", duration: "20 min", xpReward: 250, status: LessonStatus.LOCKED }] },
  { id: 6, title: "Level 6: Neural Networks", lessons: [{ id: "6-1", title: "Intro to Neurons", description: "The building blocks of Deep Learning.", content: "Weights, biases, and activation functions.", initialCode: "z = weight * input + bias", solution: "bias", duration: "25 min", xpReward: 300, status: LessonStatus.LOCKED }] },
  { id: 7, title: "Level 7: Deep Learning", lessons: [{ id: "7-1", title: "CNNs for Vision", description: "Image recognition basics.", content: "Convolutional layers and pooling.", initialCode: "model.add(Conv2D(32))", solution: "Conv2D", duration: "30 min", xpReward: 400, status: LessonStatus.LOCKED }] },
  { id: 8, title: "Level 8: Model Evaluation", lessons: [{ id: "8-1", title: "Evaluation Metrics", description: "Accuracy, Precision, Recall.", content: "Is your model actually good?", initialCode: "f1_score = 2 * (p*r) / (p+r)", solution: "score", duration: "15 min", xpReward: 200, status: LessonStatus.LOCKED }] },
  { id: 9, title: "Level 9: ML Production", lessons: [{ id: "9-1", title: "Model Deployment", description: "From notebook to real world.", content: "API endpoints and scalability.", initialCode: "import flask", solution: "flask", duration: "20 min", xpReward: 500, status: LessonStatus.LOCKED }] }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  { id: "q1", levelId: 1, question: "What is the primary difference between Supervised and Unsupervised learning?", options: ["Supervised uses labeled data", "Unsupervised is faster", "Supervised is for robots", "There is no difference"], correctAnswer: 0, explanation: "Supervised learning relies on known labels to learn mappings." },
  { id: "q2", levelId: 2, question: "Why do we scale features?", options: ["To make models larger", "To speed up training and balance weight influence", "To reduce data size", "To hide outliers"], correctAnswer: 1, explanation: "Scaling ensures features contribute equally to the distance calculations." }
];

export const DAILY_CHALLENGES: QuizQuestion[] = [
  { id: "dc1", question: "In a Decision Tree, what is 'Entropy' a measure of?", options: ["Model speed", "Data purity/disorder", "Tree height", "Memory usage"], correctAnswer: 1, explanation: "Entropy measures the impurity or randomness in the data set." },
  { id: "dc2", question: "Which activation function is most commonly used in hidden layers of Deep Neural Networks?", options: ["Step", "Linear", "ReLU", "Sigmoid"], correctAnswer: 2, explanation: "ReLU (Rectified Linear Unit) is favored for hidden layers as it helps mitigate the vanishing gradient problem." },
  { id: "dc3", question: "What does 'Overfitting' mean in ML?", options: ["Model is too simple", "Model fits noise in training data too closely", "Data is too large", "Training takes too long"], correctAnswer: 1, explanation: "Overfitting happens when a model learns the training data's noise and details to the extent that it negatively impacts performance on new data." },
  { id: "dc4", question: "In K-Nearest Neighbors, what does 'K' represent?", options: ["Number of features", "Number of training iterations", "Number of neighbors to vote", "The error rate"], correctAnswer: 2, explanation: "'K' is the number of closest neighbors used to classify a new data point." },
  { id: "dc5", question: "What is the main goal of Principal Component Analysis (PCA)?", options: ["Increase data size", "Dimensionality reduction", "Labling data", "Data augmentation"], correctAnswer: 1, explanation: "PCA is a technique used to reduce the dimensionality of large data sets while preserving as much variance as possible." }
];

export const BADGES = [
  { id: 'newbie', name: 'ML Explorer', icon: '🤖', description: 'Complete your first lesson' },
  { id: 'math-wizard', name: 'Math Wizard', icon: '📐', description: 'Unlock Level 3' },
  { id: 'data-scientist', name: 'Data Scientist', icon: '🧪', description: 'Unlock Level 5' },
  { id: 'dl-master', name: 'Deep Learner', icon: '🧠', description: 'Reach Level 7' },
  { id: 'daily-hero', name: 'Daily Hero', icon: '⚡', description: 'Complete a Daily Challenge' }
];
