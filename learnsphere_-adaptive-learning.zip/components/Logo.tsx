
import React from 'react';

interface LogoProps {
  className?: string;
  size?: number;
  variant?: 'white' | 'brand' | 'original' | 'icon';
}

export const Logo: React.FC<LogoProps> = ({ className = "", size = 40, variant = 'brand' }) => {
  // Brand Color Palette
  const lavenderPurple = "#8B5CF6"; // Vibrant Lavender (Violet-500)
  const deepViolet = "#4C1D95"; // Deep Violet (Violet-900)
  const white = "#FFFFFF";

  return (
    <svg 
      width={size} 
      height={size} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="ls-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={lavenderPurple} />
          <stop offset="100%" stopColor={deepViolet} />
        </linearGradient>
        <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="2" result="blur" />
          <feComposite in="SourceGraphic" in2="blur" operator="over" />
        </filter>
      </defs>

      {/* Background for App Icon variant */}
      {variant === 'icon' && (
         <rect width="100" height="100" fill={lavenderPurple} rx="28" />
      )}

      {/* Background shape if requested */}
      {variant === 'original' && (
         <rect width="100" height="100" fill={lavenderPurple} rx="12" />
      )}

      {/* Refined Intertwined LS Monogram */}
      <g transform="translate(15, 15) scale(0.7)">
        {/* The 'L' Path - Flowing into the base */}
        <path 
          d="M20 10 C 20 10, 15 10, 15 15 L 15 75 C 15 85, 25 90, 45 90 L 80 90 C 85 90, 90 85, 90 80 C 90 75, 85 70, 80 70 L 45 70 C 35 70, 35 65, 35 60 L 35 15 C 35 10, 30 10, 30 10 Z" 
          fill={variant === 'white' ? white : (variant === 'icon' ? white : "url(#ls-gradient)")}
          filter={variant === 'brand' ? "url(#glow)" : "none"}
        />

        {/* The 'S' Path - Intertwining through the 'L' */}
        <path 
          d="M80 10 C 60 10, 50 15, 50 30 C 50 45, 85 45, 85 65 C 85 85, 65 90, 45 90 L 45 90 C 40 90, 35 85, 35 80 C 35 75, 40 70, 45 70 L 45 70 C 55 70, 65 65, 65 55 C 65 40, 30 40, 30 25 C 30 5, 55 0, 80 0 C 85 0, 90 5, 90 10 C 90 15, 85 20, 80 10 Z" 
          fill={variant === 'white' ? white : (variant === 'icon' ? white : lavenderPurple)}
          opacity={variant === 'brand' ? 1 : 0.9}
        />
        
        {/* Subtle Overlap Highlights for depth */}
        <path 
          d="M35 30 L 35 45" 
          stroke={white} 
          strokeWidth="4" 
          strokeLinecap="round" 
          opacity="0.3" 
        />
        <path 
          d="M65 55 L 65 70" 
          stroke={white} 
          strokeWidth="4" 
          strokeLinecap="round" 
          opacity="0.3" 
        />

        {/* Monogram Highlight Dot representing the Sphere/AI Brain */}
        <circle cx="50" cy="45" r="5" fill={white} opacity="0.8" />
      </g>
    </svg>
  );
};
