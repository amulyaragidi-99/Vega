
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Bot, Loader2, Sparkles, BrainCircuit } from 'lucide-react';
import { askMentor } from '../services/gemini';
import { ChatMessage } from '../types';

export const AIAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await askMentor(messages, input);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'model', text: "Neural link interrupted. Please verify your connection." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-10 right-10 z-[100]">
      {!isOpen ? (
        <button
          onClick={() => setIsOpen(true)}
          className="group relative flex items-center justify-center"
        >
          {/* Multi-layered Pulsing Aura */}
          <div className="absolute inset-0 bg-brand/30 rounded-full blur-2xl scale-150 animate-pulse"></div>
          <div className="absolute inset-0 bg-pink-500/20 rounded-full blur-3xl scale-[2.5] animate-pulse" style={{ animationDelay: '1s' }}></div>
          
          <div className="relative bg-gradient-to-br from-brand via-purple-600 to-pink-500 text-white p-6 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.3)] transition-all group-hover:scale-110 active:scale-95 border-2 border-white/30 group-hover:rotate-12">
            <BrainCircuit size={40} className="group-hover:scale-110 transition-transform" />
            
            {/* Thinking Indicator Dot */}
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-emerald-500 rounded-full border-4 border-white dark:border-slate-900 animate-bounce shadow-xl"></div>
          </div>
          
          <div className="absolute right-full mr-6 bg-slate-900 text-white text-xs font-black px-4 py-2 rounded-xl opacity-0 group-hover:opacity-100 transition-all translate-x-4 group-hover:translate-x-0 whitespace-nowrap tracking-widest uppercase shadow-2xl">
            Summon Neural Mentor
          </div>
        </button>
      ) : (
        <div className="bg-white/90 dark:bg-slate-900/95 backdrop-blur-3xl w-[380px] md:w-[480px] h-[650px] rounded-[3.5rem] shadow-[0_50px_150px_-30px_rgba(0,0,0,0.6)] flex flex-col overflow-hidden border border-white dark:border-slate-800 animate-in zoom-in slide-in-from-bottom-10 duration-500">
          {/* Header */}
          <div className="bg-gradient-to-r from-brand via-indigo-700 to-pink-600 p-10 text-white flex justify-between items-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>
            
            <div className="flex items-center gap-4 relative z-10">
              <div className="bg-white/20 p-3 rounded-2xl backdrop-blur-md border border-white/20">
                <Sparkles size={24} className="animate-pulse" />
              </div>
              <div>
                <h3 className="font-black tracking-tight text-xl">Sphere AI</h3>
                <p className="text-[10px] uppercase font-black opacity-80 tracking-widest">Neural Link Established</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="bg-white/10 hover:bg-white/20 p-3 rounded-2xl transition-all relative z-10">
              <X size={24} />
            </button>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-8 space-y-8 scroll-smooth custom-scrollbar">
            {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-6 opacity-40">
                <BrainCircuit size={64} className="text-brand animate-float" />
                <p className="text-lg font-black max-w-[250px] leading-tight uppercase tracking-tighter">
                  Welcome to the synapse. Query the mentor.
                </p>
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                <div className={`max-w-[85%] p-6 rounded-[2.5rem] text-sm md:text-base leading-relaxed shadow-xl ${
                  m.role === 'user' 
                    ? 'bg-gradient-to-br from-brand to-indigo-700 text-white rounded-br-none' 
                    : 'bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-100 border border-slate-100 dark:border-slate-700 rounded-bl-none'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white dark:bg-slate-800 p-5 rounded-[2.5rem] rounded-bl-none shadow-xl flex items-center gap-3 border border-slate-100 dark:border-slate-700">
                  <div className="flex gap-1.5">
                    <div className="w-2 h-2 bg-brand rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-brand rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-brand rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                  <span className="text-[10px] font-black uppercase text-brand tracking-widest">Thinking...</span>
                </div>
              </div>
            )}
          </div>

          {/* Input Area */}
          <div className="p-8 bg-slate-50 dark:bg-slate-900/50 border-t border-slate-200 dark:border-slate-800">
            <div className="relative flex items-center">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Query the Sphere..."
                className="w-full bg-white dark:bg-slate-800 border-none rounded-[2.5rem] pl-8 pr-16 py-6 text-base focus:ring-4 focus:ring-brand/20 outline-none text-slate-800 dark:text-slate-100 shadow-inner font-medium"
              />
              <button
                onClick={handleSend}
                disabled={isLoading || !input.trim()}
                className="absolute right-3 bg-brand text-white p-4 rounded-[1.5rem] hover:scale-110 active:scale-95 disabled:opacity-50 transition-all shadow-2xl"
              >
                <Send size={24} />
              </button>
            </div>
            <p className="text-[10px] text-center text-slate-400 mt-6 uppercase font-black tracking-[0.2em] opacity-50">Verified AI Logic Engine</p>
          </div>
        </div>
      )}
    </div>
  );
};
