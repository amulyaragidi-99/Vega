
import React, { useState } from 'react';
import { Star, X, Send } from 'lucide-react';
import { storageService } from '../services/storage';
import { useNotification } from './NotificationSystem';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');
  const { notify } = useNotification();

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      notify("Please provide a star rating!", "warning");
      return;
    }
    storageService.saveFeedback({ rating, comment });
    notify("Thank you for your feedback!", "success");
    onClose();
    setRating(0);
    setComment('');
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white dark:bg-slate-800 w-full max-w-md rounded-[2.5rem] shadow-2xl p-10 relative">
        <button onClick={onClose} className="absolute top-6 right-6 p-2 hover:bg-slate-100 dark:hover:bg-slate-700 rounded-full transition-colors">
          <X size={20} />
        </button>

        <h2 className="text-2xl font-bold mb-2">We value your feedback</h2>
        <p className="text-slate-500 text-sm mb-8">How was your learning experience today?</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="flex justify-center gap-2">
            {[1, 2, 3, 4, 5].map(star => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                className="transition-transform active:scale-90"
              >
                <Star 
                  size={40} 
                  fill={star <= rating ? "#4f46e5" : "none"} 
                  className={star <= rating ? "text-indigo-600" : "text-slate-300 dark:text-slate-600"} 
                />
              </button>
            ))}
          </div>

          <textarea
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Any suggestions or thoughts? (Optional)"
            className="w-full bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 min-h-[120px] focus:ring-2 focus:ring-indigo-500 outline-none text-sm"
          />

          <button 
            type="submit"
            className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-200 dark:shadow-none"
          >
            Submit Feedback <Send size={18} />
          </button>
        </form>
      </div>
    </div>
  );
};
