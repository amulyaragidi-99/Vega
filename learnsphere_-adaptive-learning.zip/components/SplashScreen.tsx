
import React, { useEffect, useState } from 'react';
import { Logo } from './Logo';

export const SplashScreen: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [stage, setStage] = useState<'logo' | 'sphere'>('logo');

  useEffect(() => {
    const timer1 = setTimeout(() => {
      setStage('sphere');
    }, 1200);

    const timer2 = setTimeout(() => {
      onComplete();
    }, 3200);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[1000] bg-white flex flex-col items-center justify-center overflow-hidden">
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_100%)] from-brand/20"></div>
      </div>

      {stage === 'logo' ? (
        <div className="animate-in fade-in zoom-in duration-700 flex flex-col items-center gap-6">
          <Logo size={160} variant="brand" className="animate-pulse shadow-2xl shadow-brand/20 rounded-[3rem]" />
          <div className="text-center mt-4">
            <h1 className="text-5xl font-black tracking-tighter text-slate-900 animate-pulse leading-none uppercase">LearnSphere</h1>
            <p className="text-brand text-xs font-black tracking-[0.6em] uppercase mt-4 animate-pulse ml-1 opacity-60">Adaptive Learning</p>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-16 animate-in fade-in duration-700">
          <div className="relative w-64 h-64">
            {/* Pulsing Glow Aura */}
            <div className="absolute inset-0 bg-brand/30 rounded-full blur-[100px] animate-pulse scale-150"></div>
            
            {/* The Rotating Neural Sphere */}
            <div className="w-64 h-64 bg-gradient-to-br from-brand via-violet-600 to-indigo-900 rounded-full shadow-[inset_-25px_-25px_60px_rgba(0,0,0,0.5),0_30px_70px_rgba(139,92,246,0.4)] animate-spin-slow relative overflow-hidden border-8 border-white/10">
                {/* Surface highlight shine */}
                <div className="absolute top-6 left-12 w-20 h-10 bg-white/30 rounded-[100%] rotate-[-25deg] blur-md"></div>
                {/* Internal energy lines effect */}
                <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-from)_0%,_transparent_80%)] from-white animate-pulse"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                   <Logo size={100} variant="white" className="opacity-10 animate-pulse" />
                </div>
            </div>
          </div>
          <div className="flex flex-col items-center gap-4">
            <p className="text-brand font-black tracking-[0.5em] uppercase text-sm animate-bounce">Calibrating Synapses</p>
            <div className="flex gap-2">
                <div className="w-3 h-3 bg-brand rounded-full animate-bounce shadow-lg shadow-brand/40" style={{ animationDelay: '0s' }}></div>
                <div className="w-3 h-3 bg-brand rounded-full animate-bounce shadow-lg shadow-brand/40" style={{ animationDelay: '0.15s' }}></div>
                <div className="w-3 h-3 bg-brand rounded-full animate-bounce shadow-lg shadow-brand/40" style={{ animationDelay: '0.3s' }}></div>
            </div>
          </div>
        </div>
      )}
      
      <style>{`
        .animate-spin-slow {
          animation: spin 5s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
