
import React from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { Home, BookOpen, BarChart3, User, Settings as SettingsIcon, LogOut, Menu, X, Award, Search, Bell, ChevronLeft } from 'lucide-react';
import { storageService } from '../services/storage';
import { NotificationProvider } from './NotificationSystem';
import { Logo } from './Logo';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isSidebarOpen, setIsSidebarOpen] = React.useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    navigate('/');
  };

  const menuItems = [
    { icon: <Home size={22} />, label: 'Dashboard', path: '/dashboard' },
    { icon: <BookOpen size={22} />, label: 'Curriculum', path: '/path' },
    { icon: <Award size={22} />, label: 'Certification', path: '/certificate' },
    { icon: <BarChart3 size={22} />, label: 'Analytics', path: '/progress' },
    { icon: <SettingsIcon size={22} />, label: 'Preferences', path: '/settings' },
  ];

  return (
    <NotificationProvider>
      <div className="min-h-screen flex bg-mesh transition-colors duration-500 selection:bg-brand/20">
        {/* Background Sparkles */}
        <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
           <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-brand rounded-full blur-[150px]"></div>
           <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-pink-500 rounded-full blur-[150px]"></div>
        </div>

        {/* Universal Back to Home Button for Mobile (Top Left - Offset for Sidebar Toggle) */}
        <button 
          onClick={() => navigate('/')}
          className="lg:hidden fixed top-6 left-24 z-[60] px-5 py-4 glass rounded-[1.5rem] shadow-2xl border border-white/30 text-slate-800 dark:text-white flex items-center gap-2 font-black text-xs hover:bg-white transition-all active:scale-90"
          title="Back to Home"
        >
          <ChevronLeft size={20} className="text-brand" /> Home
        </button>

        <button 
          onClick={() => setIsSidebarOpen(!isSidebarOpen)}
          className="lg:hidden fixed top-6 left-6 z-[60] p-4 glass rounded-[1.5rem] shadow-2xl border border-white/30 text-brand"
        >
          {isSidebarOpen ? <X size={24} /> : <Menu size={24} />}
        </button>

        <aside className={`
          fixed inset-y-0 left-0 z-50 w-72 bg-white/70 dark:bg-slate-900/80 backdrop-blur-3xl border-r border-white/20 dark:border-slate-800 transition-all duration-500 transform
          ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
          shadow-[20px_0_50px_rgba(0,0,0,0.05)]
        `}>
          <div className="h-full flex flex-col p-8">
            <div className="flex items-center gap-4 mb-14 group cursor-pointer" onClick={() => navigate('/dashboard')}>
              <Logo size={44} className="group-hover:rotate-12 transition-transform" />
              <div>
                <h1 className="text-2xl font-black tracking-tighter text-slate-800 dark:text-white leading-none">LearnSphere</h1>
                <p className="text-[10px] font-black uppercase text-brand tracking-[0.2em] mt-1 opacity-90">Adaptive Learning</p>
              </div>
            </div>

            <nav className="flex-1 space-y-3">
              {menuItems.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsSidebarOpen(false)}
                  className={({ isActive }) => `
                    flex items-center gap-4 px-6 py-4 rounded-[2rem] transition-all duration-300
                    ${isActive 
                      ? 'bg-brand text-white font-black shadow-2xl shadow-brand/30 scale-105' 
                      : 'text-slate-500 dark:text-slate-400 hover:bg-white dark:hover:bg-slate-800 hover:text-brand hover:translate-x-2'}
                  `}
                >
                  {({ isActive }) => (
                    <>
                      <span className={isActive ? "text-white" : "group-hover:text-brand"}>{item.icon}</span>
                      <span className="text-sm tracking-wide">{item.label}</span>
                    </>
                  )}
                </NavLink>
              ))}
            </nav>

            <div className="pt-8 border-t border-slate-100 dark:border-slate-800 mt-auto space-y-2">
               <button 
                onClick={handleLogout}
                className="w-full flex items-center gap-4 px-6 py-4 rounded-[2rem] text-slate-400 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-900/20 transition-all font-bold"
              >
                <LogOut size={22} />
                <span className="text-sm">Disconnect</span>
              </button>
            </div>
          </div>
        </aside>

        <main className="flex-1 lg:ml-72 relative min-h-screen">
          {/* Top Bar for Desktop */}
          <header className="hidden lg:flex items-center justify-between px-10 py-6 sticky top-0 z-30 glass border-b-0">
             <div className="flex items-center gap-6">
                <button 
                  onClick={() => navigate('/')}
                  className="flex items-center gap-2 px-6 py-3 bg-white/50 hover:bg-white dark:bg-slate-800/50 dark:hover:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-2xl font-black text-sm transition-all shadow-sm hover:shadow-xl active:scale-95 group"
                >
                  <ChevronLeft size={20} className="text-brand group-hover:-translate-x-1 transition-transform" /> Back to Home
                </button>
                <div className="flex items-center gap-4 bg-slate-100 dark:bg-slate-800 px-6 py-3 rounded-2xl w-80 border border-white/10">
                  <Search size={18} className="text-slate-400" />
                  <input placeholder="Search modules..." className="bg-transparent border-none outline-none text-sm w-full" />
                </div>
             </div>
             
             <div className="flex items-center gap-6">
                <button className="relative p-3 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-2xl transition-all">
                   <Bell size={20} className="text-slate-500" />
                   <div className="absolute top-3 right-3 w-2 h-2 bg-pink-500 rounded-full ring-2 ring-white"></div>
                </button>
                <div className="h-10 w-10 bg-gradient-to-br from-brand to-pink-500 rounded-2xl shadow-lg cursor-pointer hover:rotate-6 transition-all"></div>
             </div>
          </header>

          <div className="max-w-6xl mx-auto p-6 md:p-12 lg:pt-12">
            {children}
          </div>
        </main>
      </div>
    </NotificationProvider>
  );
};
