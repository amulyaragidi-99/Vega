
import React, { useState, useEffect, createContext, useContext } from 'react';
import { X, CheckCircle, Info, AlertTriangle } from 'lucide-react';
import { Notification } from '../types';

interface NotificationContextType {
  notify: (message: string, type?: Notification['type']) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const useNotification = () => {
  const context = useContext(NotificationContext);
  if (!context) throw new Error("useNotification must be used within a NotificationProvider");
  return context;
};

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);

  const notify = (message: string, type: Notification['type'] = 'info') => {
    const id = Math.random().toString(36).substr(2, 9);
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  };

  return (
    <NotificationContext.Provider value={{ notify }}>
      {children}
      <div className="fixed top-6 right-6 z-[100] space-y-3 pointer-events-none">
        {notifications.map(n => (
          <div 
            key={n.id} 
            className={`
              pointer-events-auto flex items-center gap-3 px-6 py-4 rounded-2xl shadow-2xl border min-w-[300px] animate-in slide-in-from-right duration-300
              ${n.type === 'success' ? 'bg-emerald-50 border-emerald-100 text-emerald-800' : 
                n.type === 'warning' ? 'bg-amber-50 border-amber-100 text-amber-800' : 
                'bg-white border-slate-200 text-slate-800 dark:bg-slate-800 dark:border-slate-700 dark:text-white'}
            `}
          >
            {n.type === 'success' && <CheckCircle className="text-emerald-500" size={20} />}
            {n.type === 'warning' && <AlertTriangle className="text-amber-500" size={20} />}
            {n.type === 'info' && <Info className="text-indigo-500" size={20} />}
            <span className="flex-1 font-medium">{n.message}</span>
            <button onClick={() => setNotifications(prev => prev.filter(item => item.id !== n.id))}>
              <X size={16} />
            </button>
          </div>
        ))}
      </div>
    </NotificationContext.Provider>
  );
};
