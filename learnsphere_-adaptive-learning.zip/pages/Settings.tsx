
import React, { useState, useEffect } from 'react';
import { storageService } from '../services/storage';
import { ThemeSettings, UserStats, StudyMode } from '../types';
import { Settings as SettingsIcon, Palette, Type, Eye, Moon, Sun, Trash2, Save, Brain, Zap, CheckCircle2 } from 'lucide-react';
import { useNotification } from '../components/NotificationSystem';

export const Settings: React.FC = () => {
  const [stats, setStats] = useState<UserStats>(storageService.getUserStats());
  const { notify } = useNotification();

  const colors = [
    { name: 'Ultra Purple', value: '124, 105, 179' },
    { name: 'Neon Blue', value: '37, 99, 235' },
    { name: 'Bright Emerald', value: '5, 150, 105' },
    { name: 'Power Rose', value: '225, 29, 72' },
    { name: 'Luminous Amber', value: '245, 158, 11' },
    { name: 'Electric Violet', value: '139, 92, 246' },
  ];

  // Utility to convert hex to rgb string format "R, G, B"
  const hexToRgbStr = (hex: string): string => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    if (!result) return '124, 105, 179';
    return `${parseInt(result[1], 16)}, ${parseInt(result[2], 16)}, ${parseInt(result[3], 16)}`;
  };

  // Utility to convert rgb string "R, G, B" to hex "#RRGGBB"
  const rgbToHex = (rgb: string): string => {
    const parts = rgb.split(',').map(p => parseInt(p.trim()));
    if (parts.length !== 3) return '#7c69b3';
    return "#" + parts.map(p => p.toString(16).padStart(2, '0')).join('');
  };

  const [customHex, setCustomHex] = useState(rgbToHex(stats.settings?.primaryColor || '124, 105, 179'));

  const updateSettings = (updates: Partial<ThemeSettings>) => {
    const newStats = {
      ...stats,
      settings: { ...stats.settings!, ...updates }
    };
    setStats(newStats);
    storageService.saveUserStats(newStats);
    
    // Notify user of persistence
    if (updates.primaryColor) {
      setCustomHex(rgbToHex(updates.primaryColor));
      notify("Neural Signature Updated. Color is now persistent.", "success");
    }
  };

  const handleCustomColor = (e: React.ChangeEvent<HTMLInputElement>) => {
    const hex = e.target.value;
    const rgb = hexToRgbStr(hex);
    updateSettings({ primaryColor: rgb });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <header>
        <h1 className="text-5xl font-black text-slate-900 dark:text-white flex items-center gap-4 tracking-tighter">
          <SettingsIcon className="text-brand animate-spin-slow" size={40} /> Preferences
        </h1>
        <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">Fine-tune your training environment for maximum focus.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Luminous Controls */}
        <section className="bg-white dark:bg-slate-800 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-700 shadow-xl space-y-8">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-700 pb-6">
            <Zap className="text-amber-500" />
            <h2 className="text-2xl font-black uppercase tracking-tight">Luminous Mode</h2>
          </div>
          
          <div className="space-y-6">
            <p className="text-sm font-bold text-slate-500 uppercase tracking-widest leading-relaxed">
              Activate high-contrast "Bright Mode" to make every option and text block crystal clear.
            </p>
            
            <button 
              onClick={() => updateSettings({ highContrast: !stats.settings?.highContrast })}
              className={`
                w-full p-8 rounded-[2rem] border-4 flex items-center justify-between transition-all group
                ${stats.settings?.highContrast ? 'border-brand bg-brand/10 shadow-[0_0_30px_rgba(var(--primary-rgb),0.2)]' : 'border-slate-100 dark:border-slate-700 hover:border-brand'}
              `}
            >
              <div className="flex items-center gap-4">
                 <div className={`p-4 rounded-2xl ${stats.settings?.highContrast ? 'bg-brand text-white' : 'bg-slate-100 text-slate-400'}`}>
                    <Eye size={32} />
                 </div>
                 <div className="text-left">
                    <span className="block text-xl font-black tracking-tighter">High Visibility Mode</span>
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">{stats.settings?.highContrast ? 'Active' : 'Disabled'}</span>
                 </div>
              </div>
              <div className={`w-14 h-8 rounded-full relative transition-all ${stats.settings?.highContrast ? 'bg-brand' : 'bg-slate-300'}`}>
                <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-all ${stats.settings?.highContrast ? 'translate-x-6' : ''}`} />
              </div>
            </button>
          </div>
        </section>

        {/* Learning Persona */}
        <section className="bg-white dark:bg-slate-800 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-700 shadow-xl space-y-8">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-700 pb-6">
            <Brain className="text-brand" />
            <h2 className="text-2xl font-black uppercase tracking-tight">Study Persona</h2>
          </div>
          
          <div className="space-y-4">
            <p className="text-sm font-bold text-slate-500 uppercase tracking-widest">Default delivery method for neural concepts.</p>
            <div className="flex flex-col gap-3">
              {(['text', 'visual', 'audio'] as StudyMode[]).map((mode) => (
                <button
                  key={mode}
                  onClick={() => updateSettings({ learningPreference: mode })}
                  className={`
                    w-full p-6 rounded-[1.5rem] border-2 text-left transition-all flex items-center justify-between
                    ${stats.settings?.learningPreference === mode ? 'border-brand bg-brand/5 font-black scale-[1.02] shadow-lg' : 'border-slate-100 dark:border-slate-700 hover:border-brand'}
                  `}
                >
                  <span className="capitalize text-lg">{mode} Focused Path</span>
                  {stats.settings?.learningPreference === mode && <Zap size={20} className="text-brand animate-pulse" />}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Visual Settings - THEME COLOR SECTION */}
        <section className="lg:col-span-2 bg-white dark:bg-slate-800 p-10 rounded-[3rem] border border-slate-200 dark:border-slate-700 shadow-xl space-y-10">
          <div className="flex items-center gap-3 border-b border-slate-100 dark:border-slate-700 pb-6">
            <Palette className="text-pink-500" />
            <h2 className="text-2xl font-black uppercase tracking-tight">Neural Signature Color</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-6">Curated Presets</label>
              <div className="grid grid-cols-3 gap-4">
                {colors.map((c) => (
                  <button
                    key={c.name}
                    title={c.name}
                    onClick={() => updateSettings({ primaryColor: c.value })}
                    className={`h-16 rounded-[1.2rem] border-4 transition-all hover:scale-110 active:scale-90 relative ${stats.settings?.primaryColor === c.value ? 'border-slate-900 dark:border-white shadow-2xl scale-110' : 'border-transparent opacity-60 hover:opacity-100'}`}
                    style={{ backgroundColor: `rgb(${c.value})` }}
                  >
                    {stats.settings?.primaryColor === c.value && <div className="absolute inset-0 flex items-center justify-center text-white"><CheckCircle2 size={24} /></div>}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-6">Custom Precision Hue</label>
              <div className="flex items-center gap-4 bg-slate-50 dark:bg-slate-900 p-6 rounded-[2rem] border-2 border-slate-100 dark:border-slate-700">
                <input 
                  type="color" 
                  value={customHex}
                  onChange={handleCustomColor}
                  className="w-16 h-16 rounded-full border-none cursor-pointer bg-transparent"
                />
                <div className="flex flex-col">
                  <span className="font-mono font-black text-lg uppercase">{customHex}</span>
                  <span className="text-[10px] font-black uppercase text-slate-400">Chosen neural bias</span>
                </div>
              </div>
              <p className="text-[10px] text-slate-400 font-bold uppercase mt-4 tracking-widest leading-relaxed">This color is persistent and will be restored on every session.</p>
            </div>

            <div className="space-y-4">
               <label className="block text-xs font-black text-slate-400 uppercase tracking-[0.3em] mb-2">Display Environment</label>
               <button 
                  onClick={() => updateSettings({ darkMode: !stats.settings?.darkMode })} 
                  className={`w-full p-8 rounded-[2rem] border-2 flex items-center justify-between transition-all ${stats.settings?.darkMode ? 'bg-slate-900 border-slate-700 text-white' : 'bg-slate-50 border-slate-200 text-slate-800'}`}
                >
                  <span className="font-black text-xl flex items-center gap-4">
                    {stats.settings?.darkMode ? <Moon size={28} /> : <Sun size={28} />}
                    {stats.settings?.darkMode ? 'Dark' : 'Light'}
                  </span>
                  <div className={`w-14 h-8 rounded-full relative transition-all ${stats.settings?.darkMode ? 'bg-brand' : 'bg-slate-300'}`}>
                    <div className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full transition-all ${stats.settings?.darkMode ? 'translate-x-6' : ''}`} />
                  </div>
                </button>
            </div>
          </div>
        </section>
      </div>
      
      <section className="bg-red-50 dark:bg-red-900/10 p-12 rounded-[4rem] border border-red-100 dark:border-red-900/20 text-center space-y-6">
        <div className="inline-flex p-4 bg-red-100 dark:bg-red-900/40 text-red-600 rounded-full mb-2">
          <Trash2 size={40} />
        </div>
        <div>
          <h3 className="text-3xl font-black text-red-700 dark:text-red-400 tracking-tight">Neural Purge</h3>
          <p className="text-lg text-red-600 dark:text-red-400/60 font-medium">Resetting the adaptive core is irreversible. All training history will be deleted.</p>
        </div>
        <button onClick={() => storageService.resetProgress()} className="bg-red-600 text-white px-16 py-6 rounded-[2.5rem] font-black text-xl hover:bg-red-700 hover:scale-105 active:scale-95 transition-all shadow-2xl shadow-red-200">Wipe My Progress</button>
      </section>
    </div>
  );
};
