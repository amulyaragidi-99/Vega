
import React from 'react';
import { storageService } from '../services/storage';
import { TrendingUp, BarChart, Target, Zap, Clock, Star, ShieldCheck } from 'lucide-react';

export const Progress: React.FC = () => {
  const stats = storageService.getUserStats();
  
  const xpHistory = stats.xpHistory.slice(-7); 
  const maxXP = Math.max(...xpHistory.map(h => h.amount), 500);

  const skills = [
    { label: 'Preprocessing', count: stats.completedLessonIds.filter(id => id.startsWith('2')).length, total: 2, color: 'bg-pink-500' },
    { label: 'Regression', count: stats.completedLessonIds.filter(id => id.startsWith('3')).length, total: 1, color: 'bg-brand' },
    { label: 'Classification', count: stats.completedLessonIds.filter(id => id.startsWith('4')).length, total: 1, color: 'bg-amber-500' },
    { label: 'Deep Learning', count: stats.completedLessonIds.filter(id => id.startsWith('7')).length, total: 1, color: 'bg-emerald-500' },
  ];

  return (
    <div className="space-y-12 animate-in fade-in duration-700 pb-20">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter flex items-center gap-4">
            Analytics <TrendingUp className="text-brand" size={40} />
          </h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium">Tracing your evolution through the neural curriculum.</p>
        </div>
        <div className="hidden md:flex items-center gap-4">
           <div className="flex flex-col items-end">
             <span className="text-[10px] font-black uppercase text-slate-400">Academy Rank</span>
             <span className="text-xl font-black text-brand">Senior Architect</span>
           </div>
           <div className="bg-brand text-white p-3 rounded-2xl shadow-xl">
              <ShieldCheck size={24} />
           </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Activity Mesh Chart */}
        <section className="lg:col-span-7 bg-white/80 dark:bg-slate-800/80 backdrop-blur-xl p-10 rounded-[3.5rem] border border-slate-200 dark:border-slate-700 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-brand/5 rounded-full blur-3xl"></div>
          
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-2xl font-black flex items-center gap-3">
              <ActivityIcon /> Synaptic Activity
            </h2>
            <div className="flex gap-2">
               {[...Array(3)].map((_, i) => <div key={i} className="w-1.5 h-1.5 rounded-full bg-brand/20"></div>)}
            </div>
          </div>

          <div className="h-72 flex items-end justify-between gap-6 px-4">
            {xpHistory.map((day, idx) => {
              const height = (day.amount / maxXP) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center group relative">
                  <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-all bg-slate-900 text-white text-[10px] font-black px-3 py-1.5 rounded-xl shadow-2xl z-20 pointer-events-none transform -translate-y-2 group-hover:translate-y-0">
                    +{day.amount} XP
                  </div>
                  <div 
                    className="w-full bg-slate-100 dark:bg-slate-900/50 rounded-2xl group-hover:bg-slate-200 transition-colors flex items-end overflow-hidden"
                    style={{ height: '100%' }}
                  >
                    <div 
                      className="w-full bg-gradient-to-t from-brand to-pink-500 transition-all duration-1000 delay-100 ease-out shadow-[0_-10px_20px_rgba(var(--primary-rgb),0.3)]"
                      style={{ height: `${height}%` }}
                    ></div>
                  </div>
                  <span className="mt-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    {day.date.split('-')[2]}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Skill Proficiency Bubbles */}
        <section className="lg:col-span-5 bg-gradient-to-br from-slate-900 to-indigo-950 p-10 rounded-[3.5rem] border border-white/10 shadow-2xl text-white">
          <h2 className="text-2xl font-black mb-10 flex items-center gap-3">
            <Target size={24} className="text-pink-400" /> Neural Mapping
          </h2>

          <div className="space-y-8">
            {skills.map(skill => (
              <div key={skill.label} className="group">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center gap-2">
                    <div className={`w-2 h-2 rounded-full ${skill.color}`}></div>
                    <span className="text-sm font-bold opacity-80 group-hover:opacity-100 transition-opacity">{skill.label}</span>
                  </div>
                  <span className="text-xs font-black text-indigo-300">{Math.round((skill.count/skill.total)*100)}%</span>
                </div>
                <div className="h-4 bg-white/10 rounded-full overflow-hidden border border-white/5 p-1">
                  <div 
                    className={`h-full rounded-full transition-all duration-1000 ${skill.color} shadow-lg shadow-white/10`}
                    style={{ width: `${(skill.count/skill.total)*100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 p-6 bg-white/5 rounded-[2rem] border border-white/10 flex items-center gap-4">
             <div className="p-3 bg-pink-500/20 text-pink-400 rounded-2xl">
                <Star size={24} fill="currentColor" />
             </div>
             <div>
               <p className="text-xs font-black uppercase opacity-60">Next Rank Progress</p>
               <p className="text-lg font-bold">1200 / 5000 XP</p>
             </div>
          </div>
        </section>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        {[
          { icon: <Clock className="text-indigo-400" />, label: 'Neural Load', value: '4.2h', sub: 'Avg Focus Time' },
          { icon: <BarChart className="text-brand" />, label: 'Accuracy', value: '88%', sub: 'Global Precision' },
          { icon: <Zap className="text-amber-400" />, label: 'Resilience', value: stats.streak + 'd', sub: 'Active Streak' },
          { icon: <Target className="text-emerald-400" />, label: 'Units', value: stats.completedLessonIds.length, sub: 'Lessons Solved' }
        ].map((stat, i) => (
          <div key={i} className="bg-white/80 dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-100 dark:border-slate-700 text-center shadow-xl hover-card transition-all group">
            <div className="inline-flex p-4 bg-slate-50 dark:bg-slate-900 rounded-[1.5rem] text-slate-500 mb-4 group-hover:scale-110 transition-transform">
              {/* Fix: Use React.ReactElement<any> to resolve type mismatch when adding size prop */}
              {React.cloneElement(stat.icon as React.ReactElement<any>, { size: 28 })}
            </div>
            <p className="text-xs font-black text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <p className="text-3xl font-black text-slate-900 dark:text-white mb-2">{stat.value}</p>
            <p className="text-[10px] font-bold text-slate-400 opacity-60 uppercase">{stat.sub}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

const ActivityIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className="text-brand">
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>
  </svg>
);
