
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { storageService } from '../services/storage';
import { Lesson as LessonType, StudyMode, QuizQuestion } from '../types';
import { 
  ChevronLeft, Play, CheckCircle, Info, Lightbulb, 
  Volume2, Eye, FileText, Loader2, Sparkles, Activity,
  Pause, RotateCcw, ArrowRight, HelpCircle, XCircle
} from 'lucide-react';
import { generateLessonAudio, generateVisualSummary, generateLessonMCQs } from '../services/gemini';
import { decodeBase64, decodeAudioData } from '../services/audio';
import { useNotification } from '../components/NotificationSystem';
import confetti from 'canvas-confetti';

export const Lesson: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { notify } = useNotification();
  const [stats, setStats] = useState(storageService.getUserStats());
  
  const [lesson, setLesson] = useState<LessonType | null>(null);
  const [lessonNumber, setLessonNumber] = useState('');
  const [isCompleted, setIsCompleted] = useState(false);
  const [studyMode, setStudyMode] = useState<StudyMode>(stats.settings?.learningPreference || 'text');
  
  // Quiz state
  const [mcqs, setMcqs] = useState<QuizQuestion[]>([]);
  const [isQuizLoading, setIsQuizLoading] = useState(false);
  const [currentMcqIdx, setCurrentMcqIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [quizScore, setQuizScore] = useState(0);
  const [isQuizFinished, setIsQuizFinished] = useState(false);

  // General UI state
  const [visualContent, setVisualContent] = useState<string | null>(null);
  const [isVisualLoading, setIsVisualLoading] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [playbackState, setPlaybackState] = useState<'idle' | 'playing' | 'paused'>('idle');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const startTimeRef = useRef<number>(0);
  const pausedAtRef = useRef<number>(0);

  useEffect(() => {
    // Scroll to top on lesson change
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    const levels = storageService.getLevels();
    let foundLesson: LessonType | null = null;
    let foundNumber = '';
    
    for (const level of levels) {
      const idx = level.lessons.findIndex(l => l.id === id);
      if (idx !== -1) {
        foundLesson = level.lessons[idx];
        foundNumber = `${level.id}.${idx + 1}`;
        break;
      }
    }

    if (foundLesson) {
      setLesson(foundLesson);
      setLessonNumber(foundNumber);
      setIsCompleted(false);
      resetQuiz();
      loadStudyAids(foundLesson);
    }
    
    return () => stopAudio();
  }, [id]);

  const loadStudyAids = async (lessonObj: LessonType) => {
    setIsQuizLoading(true);
    try {
      const questions = await generateLessonMCQs(lessonObj.title, lessonObj.content);
      if (questions && questions.length > 0) {
        setMcqs(questions);
      } else {
        throw new Error("No questions generated");
      }
    } catch (err) {
      notify("Failed to load adaptive assessment. Using fallback.", "warning");
      // Fixed: Adding 'id' property to comply with QuizQuestion type
      setMcqs([{
        id: `fallback-${lessonObj.id}`,
        question: `What is the core topic of "${lessonObj.title}"?`,
        options: [lessonObj.title, "Unrelated Topic", "Random Concept", "None of above"],
        correctAnswer: 0,
        explanation: "This is an automatic validation checkpoint."
      }]);
    } finally {
      setIsQuizLoading(false);
    }

    if (stats.settings?.learningPreference === 'visual') loadVisualMode(lessonObj);
  };

  const resetQuiz = () => {
    setIsQuizFinished(false);
    setCurrentMcqIdx(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setQuizScore(0);
  };

  const handleFinish = () => {
    if (lesson) {
      storageService.completeLesson(lesson.id, lesson.xpReward);
      notify(`Module Mastered: +${lesson.xpReward} XP`, "success");
      navigate('/path');
    }
  };

  // Audio Logic
  const stopAudio = () => {
    if (sourceNodeRef.current) {
      sourceNodeRef.current.stop();
      sourceNodeRef.current = null;
    }
    pausedAtRef.current = 0;
    setPlaybackState('idle');
  };

  const pauseAudio = () => {
    if (sourceNodeRef.current && playbackState === 'playing') {
      sourceNodeRef.current.stop();
      pausedAtRef.current += audioContextRef.current!.currentTime - startTimeRef.current;
      setPlaybackState('paused');
    }
  };

  const playLessonAudio = async () => {
    if (playbackState === 'playing') {
      pauseAudio();
      return;
    }
    if (playbackState === 'paused' && audioBufferRef.current) {
      resumeAudio();
      return;
    }
    if (!lesson) return;
    
    setIsAudioLoading(true);
    try {
      const base64 = await generateLessonAudio(lesson.content);
      if (!base64) throw new Error("Audio generation failed");
      if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      }
      const audioData = decodeBase64(base64);
      const audioBuffer = await decodeAudioData(audioData, audioContextRef.current, 24000, 1);
      audioBufferRef.current = audioBuffer;
      startPlayback(audioBuffer, 0);
    } catch (err) {
      notify("Audio Narration Unavailable.", "warning");
    } finally {
      setIsAudioLoading(false);
    }
  };

  const resumeAudio = () => {
    if (audioBufferRef.current && audioContextRef.current) {
      startPlayback(audioBufferRef.current, pausedAtRef.current);
    }
  };

  const startPlayback = (buffer: AudioBuffer, offset: number) => {
    if (!audioContextRef.current) return;
    const source = audioContextRef.current.createBufferSource();
    source.buffer = buffer;
    source.connect(audioContextRef.current.destination);
    source.onended = () => {
      if (sourceNodeRef.current === source) {
        setPlaybackState('idle');
        pausedAtRef.current = 0;
      }
    };
    sourceNodeRef.current = source;
    startTimeRef.current = audioContextRef.current.currentTime;
    source.start(0, offset % buffer.duration);
    setPlaybackState('playing');
    setStudyMode('audio');
  };

  const loadVisualMode = async (lessonObj?: LessonType) => {
    const l = lessonObj || lesson;
    setStudyMode('visual');
    if (visualContent || !l) return;
    setIsVisualLoading(true);
    try {
      const summary = await generateVisualSummary(l.title, l.content);
      setVisualContent(summary);
    } catch (err) {
      notify("Visual Mapping Failed.", "warning");
      setStudyMode('text');
    } finally {
      setIsVisualLoading(false);
    }
  };

  // MCQ Logic
  const handleMcqSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);
    if (idx === mcqs[currentMcqIdx].correctAnswer) {
      setQuizScore(prev => prev + 1);
      notify("Concept Verified!", "success");
    } else {
      notify("Neural Mismatch.", "warning");
    }
  };

  const handleNextMcq = () => {
    if (currentMcqIdx < mcqs.length - 1) {
      setCurrentMcqIdx(prev => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setIsQuizFinished(true);
      if (quizScore >= 3) { // Reduced pass mark for smoother progression (60%)
        setIsCompleted(true);
        confetti({
          particleCount: 150,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#8B5CF6', '#ec4899', '#ffffff']
        });
      }
    }
  };

  if (!lesson) return <div className="p-10 text-center text-slate-400 italic">Initializing module pathways...</div>;

  return (
    <div className="max-w-5xl mx-auto pb-20 animate-in slide-in-from-bottom-10 duration-1000 relative">
      <header className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-6">
        <div className="flex items-center gap-5">
          <button onClick={() => navigate('/path')} className="p-3 glass rounded-2xl hover:scale-110 active:scale-90 transition-transform shadow-sm">
            <ChevronLeft />
          </button>
          <div>
            <span className="text-[10px] font-black text-brand uppercase tracking-widest bg-brand/10 px-3 py-1 rounded-full">Topic {lessonNumber}</span>
            <h1 className="text-4xl font-black text-slate-900 dark:text-white mt-1 tracking-tight">{lesson.title}</h1>
          </div>
        </div>
        
        <div className="flex bg-white/60 dark:bg-slate-800/60 backdrop-blur-xl p-1.5 rounded-3xl border border-white/20 dark:border-slate-700 shadow-xl self-start md:self-center transition-all">
          <button onClick={() => setStudyMode('text')} className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-bold transition-all ${studyMode === 'text' ? 'bg-white dark:bg-slate-700 shadow-lg text-brand scale-105' : 'text-slate-500 hover:text-slate-800'}`}>
            <FileText size={16} /> Text
          </button>
          <button 
            onClick={playLessonAudio} 
            className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-bold transition-all ${studyMode === 'audio' ? 'bg-white dark:bg-slate-700 shadow-lg text-brand scale-105' : 'text-slate-500 hover:text-slate-800'}`}
          >
            {isAudioLoading ? <Loader2 size={16} className="animate-spin" /> : (playbackState === 'playing' ? <Pause size={16} fill="currentColor" /> : <Volume2 size={16} />)} 
            Audio
          </button>
          <button onClick={() => loadVisualMode()} className={`flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-bold transition-all ${studyMode === 'visual' ? 'bg-white dark:bg-slate-700 shadow-lg text-brand scale-105' : 'text-slate-500 hover:text-slate-800'}`}>
            <Eye size={16} /> Visuals
          </button>
        </div>
      </header>

      <div className="space-y-12">
        {/* Instructional Core */}
        <section className="bg-white dark:bg-slate-800 p-10 md:p-14 rounded-[4rem] border border-slate-200 dark:border-slate-700 shadow-2xl relative transition-all min-h-[400px]">
          <div className="flex justify-between items-start mb-10">
             <h2 className="text-2xl font-black flex items-center gap-3 text-brand uppercase tracking-tight">
              {studyMode === 'visual' ? <Sparkles size={28} /> : studyMode === 'audio' ? <Volume2 size={28} /> : <FileText size={28} />} 
              {studyMode === 'visual' ? 'Synaptic Roadmap' : 'Instructional Core'}
            </h2>
          </div>
          
          <div className="animate-in fade-in slide-in-from-bottom-2 duration-700">
            {studyMode === 'visual' ? (
              isVisualLoading ? (
                <div className="flex flex-col items-center justify-center py-20 gap-6">
                  <Loader2 className="animate-spin text-brand" size={48} />
                  <p className="text-slate-400 font-black tracking-[0.3em] uppercase text-xs">Generating Neural Visualization...</p>
                </div>
              ) : (
                <div className="prose dark:prose-invert max-w-none whitespace-pre-wrap font-medium text-slate-700 dark:text-slate-200 text-xl leading-relaxed">
                  {visualContent}
                </div>
              )
            ) : (
              <div className="space-y-8 text-slate-700 dark:text-slate-200 leading-relaxed text-xl">
                {lesson.content}
              </div>
            )}
          </div>
        </section>

        {/* Validation Section */}
        <section className="bg-slate-50 dark:bg-slate-900/60 rounded-[4rem] border-4 border-slate-200 dark:border-slate-800 p-12 transition-all shadow-inner relative overflow-hidden">
          <div className="absolute top-0 right-0 p-12 opacity-5 pointer-events-none">
             <HelpCircle size={140} />
          </div>

          <div className="flex items-center gap-4 mb-12">
            <div className="bg-brand text-white p-4 rounded-3xl shadow-xl shadow-brand/20">
              <Activity size={32} />
            </div>
            <div>
              <h3 className="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Validation Checkpoint</h3>
              <p className="text-slate-500 font-bold">Synchronize your understanding of this module.</p>
            </div>
          </div>

          {isQuizLoading ? (
             <div className="flex flex-col items-center justify-center py-20 gap-4">
                <Loader2 className="animate-spin text-brand" size={48} />
                <p className="text-xs font-black uppercase text-slate-400 tracking-widest">Compiling Neural Assessment...</p>
             </div>
          ) : isQuizFinished ? (
            <div className="text-center space-y-10 py-10 animate-in zoom-in duration-500">
               <div className="space-y-2">
                 <div className="text-8xl font-black text-brand tracking-tighter">{Math.round((quizScore / (mcqs.length || 1)) * 100)}%</div>
                 <p className="text-xl font-bold text-slate-600">Cognitive Alignment: {quizScore}/{mcqs.length} Correct</p>
               </div>
               
               {isCompleted ? (
                 <div className="space-y-8 max-w-md mx-auto">
                   <div className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 p-6 rounded-[2.5rem] border-2 border-emerald-500/20 font-black flex items-center justify-center gap-3">
                      <CheckCircle /> Logic Protocol Verified.
                   </div>
                   <button 
                    onClick={handleFinish}
                    className="w-full bg-gradient-to-r from-brand to-indigo-600 text-white py-8 rounded-[3rem] font-black text-2xl hover:scale-105 active:scale-95 transition-all shadow-[0_20px_60px_rgba(var(--primary-rgb),0.3)] flex items-center justify-center gap-4"
                   >
                     Claim XP & Finish <ArrowRight size={32} />
                   </button>
                 </div>
               ) : (
                 <div className="space-y-8 max-w-md mx-auto">
                   <div className="bg-red-50 dark:bg-red-900/20 text-red-600 p-6 rounded-[2.5rem] border-2 border-red-500/20 font-black flex items-center justify-center gap-3">
                      <XCircle /> Insufficient Precision.
                   </div>
                   <button 
                    onClick={resetQuiz}
                    className="w-full bg-slate-900 text-white py-6 rounded-[2.5rem] font-black text-xl hover:bg-brand transition-all flex items-center justify-center gap-3 shadow-xl active:scale-95"
                   >
                     <RotateCcw size={24} /> Retry Validation
                   </button>
                 </div>
               )}
            </div>
          ) : mcqs.length > 0 ? (
            <div className="animate-in fade-in duration-500 space-y-10">
               <div className="flex justify-between items-center">
                  <span className="text-xs font-black text-brand uppercase tracking-[0.4em]">Node {currentMcqIdx + 1} / {mcqs.length}</span>
                  <div className="w-48 h-2 bg-slate-200 dark:bg-slate-800 rounded-full overflow-hidden">
                     <div className="h-full bg-brand transition-all duration-700 ease-out" style={{ width: `${((currentMcqIdx + 1) / mcqs.length) * 100}%` }}></div>
                  </div>
               </div>

               <p className="text-2xl font-black text-slate-900 dark:text-white leading-tight">{mcqs[currentMcqIdx].question}</p>

               <div className="grid grid-cols-1 gap-4">
                 {mcqs[currentMcqIdx].options.map((option, idx) => {
                   let style = "bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-100 hover:border-brand shadow-sm";
                   if (isAnswered) {
                     if (idx === mcqs[currentMcqIdx].correctAnswer) style = "bg-emerald-500 border-emerald-600 text-white shadow-xl scale-[1.02] z-10";
                     else if (idx === selectedOption) style = "bg-red-500 border-red-600 text-white opacity-40 scale-95";
                     else style = "opacity-20 pointer-events-none border-transparent";
                   } else if (selectedOption === idx) {
                     style = "border-brand bg-brand/5 shadow-lg";
                   }

                   return (
                     <button
                        key={idx}
                        onClick={() => handleMcqSelect(idx)}
                        disabled={isAnswered}
                        className={`w-full text-left p-6 rounded-[2rem] border-4 transition-all font-bold flex items-center justify-between group active:scale-[0.98] ${style}`}
                     >
                        <span className="text-lg">{option}</span>
                        {isAnswered && idx === mcqs[currentMcqIdx].correctAnswer && <CheckCircle size={24} className="animate-bounce" />}
                     </button>
                   );
                 })}
               </div>

               {isAnswered && (
                 <div className="animate-in slide-in-from-bottom-5 duration-700 space-y-8 pt-4">
                   <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border-l-8 border-brand shadow-sm">
                      <p className="text-xs font-black text-brand uppercase tracking-widest mb-2">Neural Explanation</p>
                      <p className="text-slate-700 dark:text-slate-200 font-medium italic">{mcqs[currentMcqIdx].explanation || "Correct concept mapping detected."}</p>
                   </div>
                   <button 
                    onClick={handleNextMcq}
                    className="w-full bg-slate-900 text-white py-6 rounded-[2.5rem] font-black text-xl hover:bg-brand transition-all flex items-center justify-center gap-3 shadow-2xl active:scale-95"
                   >
                     {currentMcqIdx === mcqs.length - 1 ? 'Complete Checkpoint' : 'Advance to Next Node'} <ArrowRight />
                   </button>
                 </div>
               )}
            </div>
          ) : null}
        </section>
      </div>

      {/* Floating Audio Dashboard */}
      {playbackState !== 'idle' && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[100] w-full max-w-lg px-6 animate-in slide-in-from-bottom-10 duration-700">
           <div className="bg-slate-900/95 backdrop-blur-3xl border border-white/10 rounded-[3rem] p-6 flex items-center gap-6 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.6)]">
              <div className={`w-14 h-14 rounded-2xl bg-brand flex items-center justify-center text-white shadow-xl ${playbackState === 'playing' ? 'animate-pulse' : ''}`}>
                 <Volume2 size={28} />
              </div>
              <div className="flex-1 min-w-0">
                 <p className="text-[10px] font-black text-brand uppercase tracking-[0.4em] mb-1">Neural Narrative</p>
                 <h4 className="text-white font-black text-base truncate tracking-tight">{lesson.title}</h4>
              </div>
              <div className="flex items-center gap-2">
                 {playbackState === 'playing' ? (
                   <button onClick={pauseAudio} className="p-4 bg-white/5 hover:bg-white/10 rounded-2xl text-white transition-all active:scale-90">
                      <Pause size={20} fill="currentColor" />
                   </button>
                 ) : (
                   <button onClick={resumeAudio} className="p-4 bg-brand hover:scale-105 rounded-2xl text-white transition-all shadow-lg shadow-brand/40 active:scale-90">
                      <Play size={20} fill="currentColor" />
                   </button>
                 )}
                 <button onClick={stopAudio} className="p-4 bg-red-500/10 hover:bg-red-500/20 rounded-2xl text-red-500 transition-all active:scale-90">
                    <RotateCcw size={20} />
                 </button>
              </div>
           </div>
        </div>
      )}
    </div>
  );
};
