
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { storageService } from '../services/storage';
import { Award, Download, Share2, ChevronLeft, CheckCircle2 } from 'lucide-react';
import { useNotification } from '../components/NotificationSystem';
import { Logo } from '../components/Logo';

export const Certificate: React.FC = () => {
  const stats = storageService.getUserStats();
  const isCompleted = storageService.isPathCompleted();
  const navigate = useNavigate();
  const { notify } = useNotification();

  const handleShare = async () => {
    const shareData = {
      title: 'LearnSphere Mastery Certificate',
      text: `I just mastered AI and Machine Learning on LearnSphere! 🏆`,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(shareData.text + " " + shareData.url);
        notify("Link copied to clipboard!", "success");
      }
    } catch (err) {
      console.error(err);
    }
  };

  if (!isCompleted) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center animate-in fade-in">
        <div className="bg-slate-100 p-10 rounded-[3rem] mb-10">
           <Award size={80} className="text-slate-300 mx-auto" />
        </div>
        <h1 className="text-4xl font-black mb-4 tracking-tighter uppercase">Certificate Locked</h1>
        <p className="text-slate-500 max-w-md mb-8 font-medium">Finish all the modules in your learning path to earn your official LearnSphere Adaptive Learning Certificate.</p>
        <button 
          onClick={() => navigate('/path')}
          className="bg-brand text-white px-10 py-4 rounded-full font-black hover:scale-105 transition-all shadow-xl shadow-brand/20"
        >
          View Training Path
        </button>
      </div>
    );
  }

  const today = new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });

  return (
    <div className="space-y-10 py-6 animate-in slide-in-from-bottom duration-700">
      <header className="flex flex-col md:flex-row justify-between items-center gap-6">
        <button onClick={() => navigate('/dashboard')} className="flex items-center gap-2 text-slate-500 hover:text-brand font-black transition-colors uppercase text-sm tracking-widest">
          <ChevronLeft size={20} /> Back to Dashboard
        </button>
        <div className="flex gap-4">
          <button 
            onClick={handleShare}
            className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-2xl font-black hover:bg-slate-50 transition-all shadow-sm"
          >
            <Share2 size={18} /> Share
          </button>
          <button 
            onClick={() => window.print()}
            className="flex items-center gap-2 px-8 py-4 bg-brand text-white rounded-2xl font-black hover:scale-105 transition-all shadow-2xl shadow-brand/30"
          >
            <Download size={18} /> Download Certificate
          </button>
        </div>
      </header>

      <div id="certificate" className="relative bg-white p-16 md:p-32 rounded-[4rem] shadow-2xl border-[24px] border-slate-50 max-w-5xl mx-auto overflow-hidden text-slate-900 printable-certificate">
        {/* Artistic Background Decor */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-brand/5 rounded-bl-full -z-0"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-brand/5 rounded-tr-full -z-0"></div>
        
        <div className="relative z-10 text-center space-y-10">
          <div className="flex justify-center mb-12">
             <div className="bg-brand p-6 rounded-[2.5rem] text-white shadow-2xl rotate-3">
               <Logo size={64} variant="white" />
             </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-brand font-black tracking-[0.4em] uppercase text-sm">Certificate of Mastery</h3>
            <p className="text-slate-500 text-xl font-medium italic">This is to certify that</p>
            <h2 className="text-6xl font-black tracking-tighter uppercase">{stats.name}</h2>
            <div className="w-48 h-2 bg-brand mx-auto rounded-full mt-6 opacity-20"></div>
          </div>

          <div className="space-y-4">
            <p className="text-slate-600 leading-relaxed max-w-2xl mx-auto text-lg">
              Has successfully completed the comprehensive <span className="font-black text-brand">Adaptive Machine Learning Track</span> at LearnSphere Academy, demonstrating proficiency in synaptic progression, model architecture, and ethical AI deployment.
            </p>
          </div>

          <div className="pt-16 grid grid-cols-1 md:grid-cols-2 gap-16 border-t border-slate-100">
            <div className="space-y-2">
              <p className="text-slate-400 text-xs font-black uppercase tracking-[0.3em]">Synapse Date</p>
              <p className="font-black text-2xl tracking-tighter text-slate-800">{today}</p>
            </div>
            <div className="space-y-2">
              <p className="text-slate-400 text-xs font-black uppercase tracking-[0.3em]">Validation Hash</p>
              <p className="font-mono text-slate-500 text-sm tracking-wider">{Math.random().toString(36).toUpperCase().substr(2, 16)}</p>
            </div>
          </div>

          <div className="flex flex-col items-center justify-center gap-4 pt-16">
             <div className="flex items-center gap-3">
               <CheckCircle2 size={32} className="text-brand" />
               <span className="font-black text-xl tracking-tighter uppercase text-slate-400">Verified by LearnSphere Neural Protocol</span>
             </div>
             <p className="text-[10px] font-black uppercase tracking-[0.5em] text-slate-300">Accelerating Human Intelligence</p>
          </div>
        </div>
      </div>
    </div>
  );
};
