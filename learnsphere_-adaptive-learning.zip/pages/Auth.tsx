
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { ArrowRight, Github, Mail, Lock, User as UserIcon, ChevronLeft } from 'lucide-react';
import { storageService } from '../services/storage';
import { Logo } from '../components/Logo';

interface AuthProps {
  type: 'login' | 'signup';
}

export const Auth: React.FC<AuthProps> = ({ type }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (type === 'signup') {
      const stats = storageService.getUserStats();
      storageService.saveUserStats({ ...stats, name, email });
    }
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 selection:bg-indigo-100 relative">
      <button 
        onClick={() => navigate('/')}
        className="fixed top-8 left-8 flex items-center gap-2 px-6 py-3 bg-white border-2 border-slate-900 rounded-2xl font-black text-sm transition-all shadow-[6px_6px_0px_0px_#0f172a] hover:translate-x-1 hover:translate-y-1 hover:shadow-none active:scale-95 group z-50"
      >
        <ChevronLeft size={20} className="text-brand group-hover:-translate-x-1 transition-transform" /> Back to Home
      </button>

      <div className="max-w-md w-full bg-white rounded-[3rem] shadow-2xl p-10 border-4 border-slate-900 relative">
        <div className="absolute top-0 right-0 w-32 h-32 bg-brand/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl"></div>

        <div className="flex flex-col items-center mb-10">
          <div className="mb-4">
            <Logo size={80} />
          </div>
          <h1 className="text-3xl font-black tracking-tight uppercase">LearnSphere</h1>
          <p className="text-slate-500 font-bold text-center mt-2">
            {type === 'login' ? 'Continue your ML mastery.' : 'Join the elite AI Academy today.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {type === 'signup' && (
            <div className="relative group">
              <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
              <input
                required
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl px-12 py-5 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold"
              />
            </div>
          )}
          <div className="relative group">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
            <input
              required
              type="email"
              placeholder="Email ID"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl px-12 py-5 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold"
            />
          </div>
          <div className="relative group">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
            <input
              required
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-50 border-2 border-slate-200 rounded-2xl px-12 py-5 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold"
            />
          </div>

          <button className="w-full bg-slate-900 text-white py-5 rounded-2xl font-black text-xl hover:bg-brand transition-all shadow-xl flex items-center justify-center gap-3 border-4 border-slate-900">
            {type === 'login' ? 'Synchronize' : 'Initialize'} <ArrowRight size={24} />
          </button>
        </form>

        <div className="relative my-10">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t-2 border-slate-100"></div>
          </div>
          <div className="relative flex justify-center text-[10px] font-black uppercase tracking-widest text-slate-400">
            <span className="bg-white px-4">Neural Gateway</span>
          </div>
        </div>

        <div className="flex gap-4">
          <button className="flex-1 bg-white border-2 border-slate-200 rounded-2xl py-4 flex items-center justify-center hover:bg-slate-50 transition-colors">
            <Github size={24} />
          </button>
          <button className="flex-1 bg-white border-2 border-slate-200 rounded-2xl py-4 flex items-center justify-center hover:bg-slate-50 transition-colors font-black text-brand text-2xl">
            G
          </button>
        </div>

        <p className="text-center mt-10 text-slate-500 font-bold text-sm">
          {type === 'login' ? "Don't have a signature?" : "Already synchronized?"}{' '}
          <Link to={type === 'login' ? '/signup' : '/login'} className="text-brand font-black hover:underline underline-offset-4">
            {type === 'login' ? 'Create One' : 'Reconnect'}
          </Link>
        </p>
      </div>
    </div>
  );
};
