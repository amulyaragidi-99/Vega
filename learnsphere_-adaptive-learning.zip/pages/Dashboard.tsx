
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { storageService } from '../services/storage';
import { UserStats, Level, LessonStatus } from '../types';
import { BADGES, DAILY_CHALLENGES } from '../constants';
import { Trophy, Flame, Target, Star, ChevronRight, PlayCircle, Award, MessageSquare, Zap, Brain, Activity, Cpu, Sparkles, CheckCircle2, LayoutGrid, Clock, ArrowRight } from 'lucide-react';
import { useNotification } from '../components/NotificationSystem';
import { FeedbackModal } from '../components/FeedbackModal';
import confetti from 'canvas-confetti';

export const Dashboard: React.FC = () => {
  const [stats, setStats] = useState<UserStats>(storageService.getUserStats());
  const [levels, setLevels] = useState<Level[]>(storageService.getLevels());
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [dailyChallengeIdx, setDailyChallengeIdx] = useState(0);
  
  const navigate = useNavigate();
  const { notify } = useNotification();

  useEffect(() => {
    // Refresh stats and levels on mount to ensure synchronization
    setStats(storageService.getUserStats());
    setLevels(storageService.getLevels());
    
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    setDailyChallengeIdx(dayOfYear % DAILY_CHALLENGES.length);
  }, []);

  const allLessons = levels.flatMap(l => l.lessons);
  const nextLesson = allLessons.find(l => l.status === LessonStatus.IN_PROGRESS) || 
                    (allLessons.every(l => l.status === LessonStatus.COMPLETED) ? null : allLessons.find(l => l.status === LessonStatus.LOCKED));
                    
  const currentLevel = levels.find(l => l.lessons.some(less => less.id === nextLesson?.id)) || levels[0];
  const totalLessons = allLessons.length;
  const progressPercent = Math.round((stats.completedLessonIds.length / totalLessons) * 100);

  const currentChallenge = DAILY_CHALLENGES[dailyChallengeIdx];
  const todayStr = new Date().toISOString().split('T')[0];
  const isChallengeDoneToday = stats.lastDailyChallengeDate === todayStr;

  const handleDailySubmit = (idx: number) => {
    if (isChallengeDoneToday) return;
    if (idx === currentChallenge.correctAnswer) {
      confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
      storageService.completeDailyChallenge(100);
      setStats(storageService.getUserStats());
      notify("Correct! Knowledge core updated.", "success");
    } else {
      notify("Logic mismatch. Review the concepts and try again tomorrow!", "warning");
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <FeedbackModal isOpen={isFeedbackOpen} onClose={() => setIsFeedbackOpen(false)} />
      
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="animate-in slide-in-from-left duration-700">
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">
            Welcome back, {stats.name.split(' ')[0]}! 👋
          </h1>
          <p className="text-slate-500 dark:text-slate-400 font-bold mt-1">
            {progressPercent === 100 
              ? "Mastery achieved. Neural protocols fully synced." 
              : `Current Phase: ${currentLevel.title.split(':')[1] || currentLevel.title}`}
          </p>
        </div>
        <div className="flex items-center gap-3 animate-in slide-in-from-right duration-700">
          <div className="bg-orange-50 dark:bg-orange-900/20 text-orange-600 px-5 py-2.5 rounded-2xl flex items-center gap-2 font-black border border-orange-100 dark:border-orange-800/30 shadow-sm transition-transform hover:scale-105 cursor-default">
            <Flame size={20} fill="currentColor" />
            <span>{stats.streak} Day Streak</span>
          </div>
          <button 
            onClick={() => setIsFeedbackOpen(true)} 
            className="p-3 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 hover:text-brand hover:border-brand transition-all shadow-sm active:scale-90"
            title="Provide Feedback"
          >
            <MessageSquare size={20} />
          </button>
        </div>
      </header>

      {/* Progress Card */}
      <section className="bg-white dark:bg-slate-800 p-8 md:p-10 rounded-[3rem] border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden relative group">
        <div className="absolute top-0 right-0 p-8 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity duration-1000 pointer-events-none">
           <Brain size={240} />
        </div>
        
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-10 items-center">
          <div className="space-y-2">
            <p className="text-xs font-black uppercase text-slate-400 tracking-widest">Training Progress</p>
            <div className="flex items-baseline gap-2">
              <span className="text-6xl font-black text-slate-900 dark:text-white">{progressPercent}%</span>
              <span className="text-slate-400 font-bold uppercase text-[10px]">Complete</span>
            </div>
          </div>

          <div className="md:col-span-2 space-y-6">
            <div className="h-4 bg-slate-100 dark:bg-slate-900 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
              <div 
                className="h-full bg-brand transition-all duration-1000 ease-out shadow-[0_0_20px_rgba(var(--primary-rgb),0.4)]" 
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            <div className="flex justify-between text-[10px] font-black uppercase text-slate-400 tracking-widest">
              <span>Foundation</span>
              <span>Advanced AI Architect</span>
            </div>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Next Step - Main Action */}
        <div className="lg:col-span-7">
          <div 
            onClick={() => nextLesson && navigate(`/lesson/${nextLesson.id}`)}
            className={`
              group h-full p-10 rounded-[3rem] transition-all cursor-pointer shadow-2xl flex flex-col justify-between relative overflow-hidden active:scale-[0.98]
              ${progressPercent === 100 
                ? 'bg-emerald-600 text-white' 
                : 'bg-slate-900 text-white hover:border-brand border-4 border-slate-900'}
            `}
          >
            <div className="absolute -bottom-10 -right-10 opacity-10 group-hover:scale-110 group-hover:rotate-12 transition-transform duration-1000 pointer-events-none">
               {progressPercent === 100 ? <Award size={240} /> : <Zap size={240} />}
            </div>
            
            <div className="relative z-10">
              <span className={`text-[10px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest border ${progressPercent === 100 ? 'bg-white/20 border-white/30' : 'bg-brand/20 text-brand border-brand/30'}`}>
                {progressPercent === 100 ? 'Global Mastery' : 'Next Critical Node'}
              </span>
              <h2 className="text-4xl font-black mt-6 tracking-tight group-hover:translate-x-2 transition-transform">
                {progressPercent === 100 ? "Curriculum Complete!" : (nextLesson?.title || "Initiate Learning")}
              </h2>
              <p className="text-slate-300 font-medium mt-4 max-w-sm line-clamp-2">
                {progressPercent === 100 
                  ? "You have processed every module. Claim your mastery certification." 
                  : (nextLesson?.description || "Accelerate your neural development by initializing the first instructional node.")}
              </p>
            </div>

            <div className="mt-12 relative z-10 flex items-center justify-between">
              <button 
                onClick={(e) => {
                  if (progressPercent === 100) {
                    e.stopPropagation();
                    navigate('/certificate');
                  }
                }}
                className={`px-8 py-4 rounded-2xl font-black text-lg flex items-center gap-3 transition-all shadow-xl hover:scale-105 active:scale-95 ${progressPercent === 100 ? 'bg-white text-emerald-600' : 'bg-brand text-white'}`}
              >
                {progressPercent === 100 ? 'Claim Certificate' : 'Resume Training'} <ChevronRight />
              </button>
              {nextLesson && (
                <div className="flex items-center gap-2 text-brand font-black text-sm uppercase">
                  <Clock size={18} /> {nextLesson.duration}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="lg:col-span-5 grid grid-cols-2 gap-6">
          <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-700 flex flex-col justify-center items-center text-center shadow-sm hover:shadow-md transition-all group">
            <div className="bg-brand/10 p-4 rounded-2xl text-brand mb-4 group-hover:rotate-12 transition-transform">
              <Zap size={28} />
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total XP</p>
            <p className="text-3xl font-black text-slate-900 dark:text-white">{stats.xp.toLocaleString()}</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-700 flex flex-col justify-center items-center text-center shadow-sm hover:shadow-md transition-all group">
            <div className="bg-pink-100 dark:bg-pink-900/20 p-4 rounded-2xl text-pink-500 mb-4 group-hover:-rotate-12 transition-transform">
              <Award size={28} />
            </div>
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Badges</p>
            <p className="text-3xl font-black text-slate-900 dark:text-white">{stats.badges.length}</p>
          </div>

          <div className="bg-white dark:bg-slate-800 p-8 rounded-[2.5rem] border border-slate-200 dark:border-slate-700 flex flex-col justify-center items-center text-center shadow-sm hover:shadow-md transition-all col-span-2 group">
            <div className="flex items-center gap-3 mb-4">
               {stats.badges.length > 0 ? (
                 stats.badges.slice(-4).map(b => (
                   <div key={b} className="w-10 h-10 bg-slate-50 dark:bg-slate-900 rounded-full flex items-center justify-center text-xl shadow-sm border border-slate-200 dark:border-slate-700 hover:scale-110 transition-transform cursor-help" title={BADGES.find(x => x.id === b)?.name}>
                     {BADGES.find(x => x.id === b)?.icon}
                   </div>
                 ))
               ) : (
                 <div className="h-10 flex items-center">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">No badges earned yet</span>
                 </div>
               )}
            </div>
            <button onClick={() => navigate('/progress')} className="text-xs font-black text-brand uppercase tracking-widest flex items-center gap-2 hover:translate-x-1 transition-transform active:opacity-50">
              View Analytics <ChevronRight size={14} />
            </button>
          </div>
        </div>
      </div>

      {/* Daily Challenge */}
      <section className="bg-slate-50 dark:bg-slate-900/40 border border-slate-200 dark:border-slate-800 rounded-[3rem] p-8 md:p-10 flex flex-col md:flex-row items-center gap-10 hover:shadow-inner transition-all">
        <div className="md:w-1/3 space-y-3 text-center md:text-left">
           <div className="inline-flex items-center gap-2 bg-amber-100 dark:bg-amber-900/30 text-amber-600 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest border border-amber-200 dark:border-amber-800/30">
              <Sparkles size={14} /> Daily Logic Check
           </div>
           <h3 className="text-2xl font-black text-slate-900 dark:text-white">Quick Sync</h3>
           <p className="text-slate-500 font-medium leading-relaxed">Demonstrate consistent mastery to maintain your streak.</p>
        </div>

        <div className="flex-1 w-full">
          {isChallengeDoneToday ? (
            <div className="bg-emerald-500/10 border-2 border-dashed border-emerald-500/30 rounded-[2rem] p-10 text-center flex flex-col items-center gap-4 animate-in zoom-in duration-500">
               <div className="bg-emerald-500 text-white p-3 rounded-full shadow-lg shadow-emerald-500/20">
                 <CheckCircle2 size={32} />
               </div>
               <p className="text-emerald-600 font-black text-lg uppercase tracking-tight">Sync Complete! See you tomorrow.</p>
            </div>
          ) : (
            <div className="space-y-6">
              <p className="text-lg font-bold text-slate-800 dark:text-slate-200 leading-tight">{currentChallenge.question}</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {currentChallenge.options.map((opt, i) => (
                  <button 
                    key={i} 
                    onClick={() => handleDailySubmit(i)}
                    className="p-5 bg-white dark:bg-slate-800 border-2 border-slate-200 dark:border-slate-700 rounded-2xl text-left font-black text-sm hover:border-brand hover:shadow-lg transition-all active:scale-[0.97]"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};
