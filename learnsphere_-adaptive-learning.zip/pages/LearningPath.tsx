
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { storageService } from '../services/storage';
import { LessonStatus } from '../types';
import { Lock, CheckCircle2, Circle, Clock, Zap, Award } from 'lucide-react';

export const LearningPath: React.FC = () => {
  const levels = storageService.getLevels();
  const navigate = useNavigate();

  return (
    <div className="space-y-12 animate-in slide-in-from-bottom duration-700">
      <header className="text-center">
        <h1 className="text-4xl font-black text-slate-900 dark:text-white uppercase tracking-tighter">Super ML Path</h1>
        <p className="text-slate-500 dark:text-slate-400 mt-2 max-w-lg mx-auto">9 Stages from Foundation to Production. Disciplined progression only.</p>
      </header>

      <div className="space-y-20 pb-20 relative">
        <div className="absolute top-0 bottom-0 left-[23px] w-1 bg-slate-200 dark:bg-slate-800 -z-0"></div>
        
        {levels.map((level, lIdx) => (
          <div key={level.id} className="relative z-10">
            <div className="flex items-center gap-6 mb-10">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center text-white font-bold text-xl shadow-lg ${level.quizPassed ? 'bg-emerald-500' : 'bg-brand'}`}>
                {level.quizPassed ? <CheckCircle2 size={24} /> : level.id}
              </div>
              <h2 className="text-2xl font-black text-slate-800 dark:text-slate-100 uppercase tracking-tight">{level.title}</h2>
            </div>

            <div className="ml-16 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {level.lessons.map((lesson, lessonIdx) => {
                const isLocked = lesson.status === LessonStatus.LOCKED;
                const isCompleted = lesson.status === LessonStatus.COMPLETED;
                const hierarchicalNumber = `${level.id}.${lessonIdx + 1}`;

                return (
                  <div 
                    key={lesson.id}
                    onClick={() => !isLocked && navigate(`/lesson/${lesson.id}`)}
                    className={`
                      group relative bg-white dark:bg-slate-800 p-6 rounded-[2rem] border-2 transition-all cursor-pointer
                      ${isLocked 
                        ? 'opacity-60 border-slate-100 dark:border-slate-800' 
                        : 'border-slate-200 dark:border-slate-700 hover:border-brand shadow-sm hover:-translate-y-1'}
                    `}
                  >
                    <div className="flex justify-between items-start mb-4">
                      <div className={`p-3 rounded-2xl ${isCompleted ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'}`}>
                        {isCompleted ? <CheckCircle2 size={20} /> : isLocked ? <Lock size={20} /> : <Circle size={20} />}
                      </div>
                      <div className="flex flex-col items-end">
                        <div className="px-2 py-1 bg-brand/5 rounded-lg text-[10px] font-black text-brand uppercase">{lesson.xpReward} XP</div>
                        <div className="mt-2 text-[10px] font-black text-slate-400 opacity-60">TOPIC {hierarchicalNumber}</div>
                      </div>
                    </div>
                    <h3 className="font-bold text-lg text-slate-800 dark:text-slate-100">
                      {hierarchicalNumber} {lesson.title}
                    </h3>
                    <div className="flex items-center gap-2 text-slate-400 text-[10px] font-bold mt-4 uppercase">
                      <Zap size={12} className="text-brand" /> Self-Paced Training
                    </div>
                  </div>
                );
              })}

              {/* Level Quiz Card */}
              <div 
                onClick={() => level.lessons.every(l => l.status === LessonStatus.COMPLETED) && navigate('/quiz')}
                className={`
                  p-6 rounded-[2rem] border-2 flex flex-col items-center justify-center text-center transition-all cursor-pointer
                  ${level.quizPassed 
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-600' 
                    : level.lessons.every(l => l.status === LessonStatus.COMPLETED)
                      ? 'border-amber-400 bg-amber-50 text-amber-700 animate-pulse'
                      : 'border-dashed border-slate-200 text-slate-300 pointer-events-none'}
                `}
              >
                <Award size={32} className="mb-2" />
                <h3 className="font-bold">Mastery Quiz</h3>
                <p className="text-[10px] uppercase font-bold mt-1">Unlock Level {level.id + 1}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
