
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { QUIZ_QUESTIONS } from '../constants';
import { storageService } from '../services/storage';
import { ArrowRight, RotateCcw, CheckCircle2, XCircle, Target } from 'lucide-react';
import confetti from 'canvas-confetti';

export const Quiz: React.FC = () => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const navigate = useNavigate();

  const question = QUIZ_QUESTIONS[currentIdx];

  const handleOptionSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);
    if (idx === question.correctAnswer) {
      setScore(score + 1);
      confetti({ particleCount: 40, spread: 30, origin: { y: 0.7 } });
    }
  };

  const handleNext = () => {
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResult(true);
      if (score + (selectedOption === question.correctAnswer ? 1 : 0) === QUIZ_QUESTIONS.length) {
        confetti({ particleCount: 200, spread: 160, origin: { y: 0.5 } });
      }
    }
  };

  if (showResult) {
    const percentage = Math.round((score / QUIZ_QUESTIONS.length) * 100);
    return (
      <div className="flex flex-col items-center justify-center py-20 animate-in zoom-in duration-700">
        <div className="bg-white dark:bg-slate-800 p-16 rounded-[4rem] shadow-2xl text-center border-8 border-slate-900 max-w-xl w-full">
          <h1 className="text-5xl font-black mb-4 text-slate-900 dark:text-white">Validation Complete</h1>
          <div className="text-9xl font-black text-brand mb-8">{percentage}%</div>
          <div className="grid grid-cols-2 gap-4">
            <button onClick={() => navigate('/dashboard')} className="bg-slate-900 text-white py-5 rounded-3xl font-black text-xl hover:scale-105 transition-all">Hub</button>
            <button onClick={() => window.location.reload()} className="bg-slate-100 text-slate-900 py-5 rounded-3xl font-black text-xl hover:bg-slate-200 transition-all"><RotateCcw size={24} className="mx-auto"/></button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto py-12 space-y-10 animate-in slide-in-from-right duration-700">
      <div className="flex justify-between items-end">
        <h2 className="text-4xl font-black text-slate-900 dark:text-white">Logic Validation</h2>
        <span className="font-black text-brand">{currentIdx + 1} / {QUIZ_QUESTIONS.length}</span>
      </div>

      <div className="bg-white dark:bg-slate-800 p-12 rounded-[4rem] border-4 border-slate-900 shadow-2xl relative">
        <p className="text-2xl font-black mb-12 text-slate-900 dark:text-white leading-relaxed">{question.question}</p>
        
        <div className="grid grid-cols-1 gap-4">
          {question.options.map((option, idx) => {
            let stateClass = "bg-white border-slate-900 text-slate-900 hover:bg-slate-100 shadow-lg";
            if (isAnswered) {
              if (idx === question.correctAnswer) stateClass = "bg-emerald-500 border-slate-900 text-slate-900 shadow-2xl scale-105";
              else if (idx === selectedOption) stateClass = "bg-red-500 border-slate-900 text-white opacity-50";
              else stateClass = "bg-slate-50 border-slate-200 text-slate-300 pointer-events-none";
            } else if (selectedOption === idx) {
              stateClass = "bg-brand border-slate-900 text-white shadow-2xl scale-105";
            }

            return (
              <button
                key={idx}
                onClick={() => handleOptionSelect(idx)}
                disabled={isAnswered}
                className={`w-full text-left p-8 rounded-[2rem] border-4 transition-all font-black flex items-center justify-between ${stateClass}`}
              >
                <span className="text-xl">{option}</span>
                {isAnswered && idx === question.correctAnswer && <CheckCircle2 size={24} />}
                {isAnswered && idx === selectedOption && idx !== question.correctAnswer && <XCircle size={24} />}
              </button>
            );
          })}
        </div>

        {isAnswered && (
          <button onClick={handleNext} className="mt-12 w-full bg-slate-900 text-white py-6 rounded-3xl font-black text-2xl hover:bg-brand transition-all flex items-center justify-center gap-3">
            {currentIdx === QUIZ_QUESTIONS.length - 1 ? 'Commit' : 'Next Node'} <ArrowRight size={28} />
          </button>
        )}
      </div>
    </div>
  );
};
