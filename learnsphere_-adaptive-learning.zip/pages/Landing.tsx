
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Zap, TrendingUp, Sparkles, Star, ShieldCheck, X, Mail, Lock, User as UserIcon, ArrowRight } from 'lucide-react';
import { Logo } from '../components/Logo';
import { storageService } from '../services/storage';

export const Landing: React.FC = () => {
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    const stats = storageService.getUserStats();
    storageService.saveUserStats({ ...stats, name, email });
    navigate('/dashboard');
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-transparent text-slate-900 selection:bg-brand/10 scroll-smooth">
      {/* Navbar */}
      <nav className="max-w-7xl mx-auto px-6 py-10 flex justify-between items-center relative z-20">
        <div className="flex items-center gap-5 group cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          <Logo size={52} className="group-hover:rotate-12 transition-transform duration-500" variant="brand" />
          <div className="flex flex-col">
            <span className="font-black text-4xl tracking-tighter text-slate-900 uppercase leading-none">LearnSphere</span>
            <span className="text-[10px] font-black uppercase text-brand tracking-[0.4em] mt-1 ml-0.5">Adaptive Learning</span>
          </div>
        </div>
        <div className="hidden md:flex items-center gap-10">
          <button onClick={() => scrollToSection('features')} className="text-sm font-black uppercase tracking-widest text-slate-500 hover:text-brand transition-all">Features</button>
          
          <button 
            onClick={() => setShowAuthModal(true)} 
            className="text-sm font-black uppercase tracking-widest text-slate-900 hover:text-brand transition-all"
          >
            Login
          </button>
          
          <button 
            onClick={() => setShowAuthModal(true)} 
            className="bg-slate-900 text-white px-8 py-4 rounded-full hover:bg-brand transition-all shadow-2xl hover:scale-105 active:scale-95 font-black uppercase text-xs tracking-widest"
          >
            Get Started
          </button>
        </div>
      </nav>

      {/* Hero */}
      <section className="max-w-7xl mx-auto px-6 pt-24 pb-48 text-center relative overflow-hidden z-10">
        <div className="mb-12 relative z-10">
          <h2 className="text-7xl md:text-9xl font-black tracking-tighter text-slate-900 mb-4 animate-in fade-in slide-in-from-top-10 duration-1000 uppercase leading-none">
            Machine <span className="text-gradient">Learning</span>
          </h2>
          <div className="h-2 w-48 bg-brand mx-auto rounded-full mb-10 opacity-20"></div>
        </div>

        <h1 className="text-3xl md:text-6xl font-black tracking-tight mb-12 text-slate-800 leading-[1.1] max-w-4xl mx-auto relative z-10">
          The ultimate environment for mastering Artificial Intelligence.
        </h1>
        
        <p className="text-xl md:text-2xl text-slate-500 max-w-3xl mx-auto mb-20 leading-relaxed font-medium relative z-10">
          Accelerate your expertise with <span className="text-slate-900 font-black underline decoration-brand/30 decoration-4">Interactive Puzzles</span>, browser-based logic gates, and a curriculum that adapts to your cognition.
        </p>
      </section>

      {/* Features Section */}
      <section id="features" className="py-40 bg-slate-900 relative">
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-32">
            <h2 className="text-5xl md:text-7xl font-black mb-8 text-white tracking-tighter uppercase">Built for Intelligence</h2>
            <div className="w-24 h-2 bg-brand mx-auto rounded-full mb-8"></div>
            <p className="text-slate-400 max-w-2xl mx-auto text-xl font-medium tracking-wide">LearnSphere maps the Machine Learning landscape into atomic nodes for hyper-focus.</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-10">
            {[
              { icon: <Zap size={40} />, title: "Synapse Loops", desc: "Short-circuit the learning curve with bite-sized cognitive cycles.", color: "bg-brand" },
              { icon: <ShieldCheck size={40} />, title: "Verified Mastery", desc: "Unlock cryptographic proof of your intelligence as you progress.", color: "bg-indigo-600" },
              { icon: <TrendingUp size={40} />, title: "Growth Trace", desc: "Real-time analytics on your neural weights and skill biases.", color: "bg-emerald-500" },
              { icon: <Star size={40} />, title: "Elite Badges", desc: "Earn recognition within the global LearnSphere developer network.", color: "bg-pink-500" }
            ].map((f, i) => (
              <div key={i} className="bg-white/5 backdrop-blur-3xl p-12 rounded-[4rem] border border-white/10 hover:bg-white/10 transition-all duration-500 group shadow-2xl">
                <div className={`${f.color} w-24 h-24 rounded-[2.5rem] flex items-center justify-center mb-10 shadow-2xl group-hover:scale-110 group-hover:-rotate-3 transition-all duration-300`}>
                  {React.cloneElement(f.icon as React.ReactElement<any>, { className: "text-white" })}
                </div>
                <h3 className="font-black text-2xl mb-4 text-white uppercase tracking-tighter">{f.title}</h3>
                <p className="text-slate-400 text-base leading-relaxed font-medium">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-40 bg-white text-center relative overflow-hidden">
        <div className="max-w-4xl mx-auto px-6 relative z-10">
          <h2 className="text-6xl md:text-8xl font-black mb-12 uppercase tracking-tighter text-slate-900 leading-none">Ready to <span className="text-brand">Sync?</span></h2>
          <p className="text-2xl font-bold text-slate-500 max-w-2xl mx-auto mb-12">Join the next generation of AI architects training on LearnSphere.</p>
          <button 
            onClick={() => setShowAuthModal(true)} 
            className="inline-flex bg-slate-900 text-white px-12 py-6 rounded-full font-black text-xl hover:bg-brand transition-all shadow-2xl hover:scale-105 active:scale-95 uppercase tracking-widest"
          >
            Get Started Now
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-24 text-center text-slate-400 bg-slate-50 border-t border-slate-100 flex flex-col items-center gap-10">
        <Logo size={80} variant="brand" className="opacity-40 grayscale hover:grayscale-0 transition-all cursor-pointer" />
        <div className="flex gap-12 text-[10px] font-black uppercase tracking-[0.4em]">
            <a href="#" className="hover:text-brand transition-colors">Twitter</a>
            <a href="#" className="hover:text-brand transition-colors">GitHub</a>
            <a href="#" className="hover:text-brand transition-colors">Discord</a>
        </div>
        <p className="font-black tracking-[0.2em] uppercase text-[10px] opacity-40">© 2024 LearnSphere Academy. All Neural Rights Reserved.</p>
      </footer>

      {/* Auth Modal Overlay */}
      {showAuthModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-900/80 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[4rem] shadow-3xl p-12 relative animate-in zoom-in duration-500 overflow-hidden border-4 border-slate-900">
            <button 
              onClick={() => setShowAuthModal(false)} 
              className="absolute top-10 right-10 p-4 hover:bg-slate-100 rounded-[1.5rem] transition-all z-10"
            >
              <X size={28} className="text-slate-900" />
            </button>

            <div className="flex flex-col items-center mb-12">
              <Logo size={100} className="mb-6" variant="brand" />
              <h2 className="text-3xl font-black tracking-tighter text-slate-900 uppercase">LearnSphere</h2>
              <p className="text-slate-500 text-center mt-4 font-bold">Access the global neural network.</p>
            </div>

            <form onSubmit={handleSignup} className="space-y-6">
              <div className="relative group">
                <UserIcon className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
                <input
                  required
                  type="text"
                  placeholder="Your Name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[2rem] pl-16 pr-8 py-6 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold text-lg"
                />
              </div>
              <div className="relative group">
                <Mail className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
                <input
                  required
                  type="email"
                  placeholder="Email ID"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[2rem] pl-16 pr-8 py-6 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold text-lg"
                />
              </div>
              <div className="relative group">
                <Lock className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-brand" size={20} />
                <input
                  required
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-slate-50 border-2 border-slate-100 rounded-[2rem] pl-16 pr-8 py-6 focus:ring-4 focus:ring-brand/10 focus:border-brand outline-none transition-all font-bold text-lg"
                />
              </div>

              <button type="submit" className="w-full bg-slate-900 text-white py-6 rounded-[2rem] font-black text-xl hover:bg-brand transition-all shadow-2xl flex items-center justify-center gap-4 group mt-4">
                Initialize Access <ArrowRight size={24} className="group-hover:translate-x-2 transition-transform" />
              </button>
            </form>

            <p className="text-center mt-12 text-slate-400 text-[10px] font-black uppercase tracking-[0.3em] opacity-60">
              Verified Learning Protocol v5.1
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
